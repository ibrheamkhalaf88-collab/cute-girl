import { createContext, useContext, useState, useEffect, useMemo, ReactNode } from "react";
import { I18nManager } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

type Language = "ar" | "en";

interface LanguageContextValue {
  lang: Language;
  isRTL: boolean;
  setLanguage: (l: Language) => Promise<void>;
  t: (key: string, texts?: Record<string, { ar: string; en: string }>) => string;
}

const translations: Record<string, { ar: string; en: string }> = {
  app_name: { ar: "بيوتي زون", en: "Beauty Zone" },
  home: { ar: "الرئيسية", en: "Home" },
  categories: { ar: "التصنيفات", en: "Categories" },
  stores: { ar: "المتاجر", en: "Stores" },
  cart: { ar: "السلة", en: "Cart" },
  settings: { ar: "الإعدادات", en: "Settings" },
  login: { ar: "تسجيل الدخول", en: "Sign In" },
  register: { ar: "إنشاء حساب", en: "Sign Up" },
  search: { ar: "بحث...", en: "Search..." },
  search_products: { ar: "ابحث عن منتجات...", en: "Search products..." },
  orders: { ar: "طلباتي", en: "My Orders" },
  profile: { ar: "الملف الشخصي", en: "Profile" },
  notifications: { ar: "الإشعارات", en: "Notifications" },
  support: { ar: "الدعم", en: "Support" },
  add_to_cart: { ar: "أضف للسلة", en: "Add to Cart" },
  checkout: { ar: "إتمام الطلب", en: "Checkout" },
  featured_products: { ar: "منتجات مميزة", en: "Featured" },
  see_all: { ar: "عرض الكل", en: "See All" },
  welcome: { ar: "مرحباً بك", en: "Welcome" },
  language: { ar: "اللغة", en: "Language" },
  change_password: { ar: "تغيير كلمة المرور", en: "Change Password" },
  username: { ar: "اسم المستخدم", en: "Username" },
  password: { ar: "كلمة المرور", en: "Password" },
  full_name: { ar: "الاسم الكامل", en: "Full Name" },
  email: { ar: "البريد الإلكتروني", en: "Email" },
  phone: { ar: "رقم الهاتف", en: "Phone Number" },
  address: { ar: "المنطقة", en: "Area / Address" },
  complete_profile: { ar: "أكمل ملفك الشخصي", en: "Complete Your Profile" },
  complete_profile_desc: { ar: "يجب إكمال ملفك الشخصي قبل الطلب", en: "Complete your profile to start ordering" },
  save: { ar: "حفظ", en: "Save" },
  logout: { ar: "تسجيل خروج", en: "Sign Out" },
  dont_have_account: { ar: "ليس لديك حساب؟", en: "Don't have an account?" },
  already_have_account: { ar: "لديك حساب بالفعل؟", en: "Already have an account?" },
  current_password: { ar: "كلمة المرور الحالية", en: "Current Password" },
  new_password: { ar: "كلمة المرور الجديدة", en: "New Password" },
  confirm_password: { ar: "تأكيد كلمة المرور", en: "Confirm Password" },
  no_products: { ar: "لا توجد منتجات", en: "No products found" },
  no_orders: { ar: "لا توجد طلبات", en: "No orders yet" },
  order_placed: { ar: "تم تقديم الطلب", en: "Order placed!" },
  empty_cart: { ar: "السلة فارغة", en: "Your cart is empty" },
  total: { ar: "المجموع", en: "Total" },
  subtotal: { ar: "المجموع الفرعي", en: "Subtotal" },
  delivery_fee: { ar: "رسوم التوصيل", en: "Delivery Fee" },
  free: { ar: "مجاني", en: "Free" },
  place_order: { ar: "تأكيد الطلب", en: "Place Order" },
  payment_method: { ar: "طريقة الدفع", en: "Payment Method" },
  bank_transfer: { ar: "تحويل بنكي", en: "Bank Transfer" },
  cash_on_delivery: { ar: "الدفع عند الاستلام", en: "Cash on Delivery" },
  deposit_delivery: { ar: "دفعة + عند الاستلام", en: "Deposit + COD" },
  delivery_address: { ar: "عنوان التوصيل", en: "Delivery Address" },
  notes: { ar: "ملاحظات", en: "Notes" },
  shekel: { ar: "₪", en: "₪" },
  product_details: { ar: "تفاصيل المنتج", en: "Product Details" },
  suitable_for: { ar: "مناسب لـ", en: "Suitable for" },
  ingredients: { ar: "المكونات", en: "Ingredients" },
  how_to_use: { ar: "طريقة الاستخدام", en: "How to use" },
  warnings_label: { ar: "تحذيرات", en: "Warnings" },
  user_id: { ar: "رقم المستخدم", en: "User ID" },
  arabic: { ar: "العربية", en: "Arabic" },
  english: { ar: "English", en: "English" },
  browse_categories: { ar: "تصفح التصنيفات", en: "Browse Categories" },
  all_products: { ar: "جميع المنتجات", en: "All Products" },
  explore: { ar: "استكشف", en: "Explore" },
  account: { ar: "حسابي", en: "Account" },
  order_status: { ar: "حالة الطلب", en: "Order Status" },
  quantity: { ar: "الكمية", en: "Quantity" },
  remove: { ar: "إزالة", en: "Remove" },
  continue_shopping: { ar: "متابعة التسوق", en: "Continue Shopping" },
  items: { ar: "عناصر", en: "items" },
};

const LanguageContext = createContext<LanguageContextValue | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Language>("ar");

  useEffect(() => {
    AsyncStorage.getItem("app_language").then((l) => {
      if (l === "ar" || l === "en") setLang(l);
    });
  }, []);

  const isRTL = lang === "ar";

  async function setLanguage(l: Language) {
    setLang(l);
    await AsyncStorage.setItem("app_language", l);
  }

  function t(key: string, serverTexts?: Record<string, { ar: string; en: string }>) {
    const allTexts = serverTexts ? { ...translations, ...serverTexts } : translations;
    const entry = allTexts[key];
    if (!entry) return key;
    return entry[lang] || entry.en || key;
  }

  const value = useMemo(() => ({ lang, isRTL, setLanguage, t }), [lang]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) throw new Error("useLanguage must be used within LanguageProvider");
  return context;
}
