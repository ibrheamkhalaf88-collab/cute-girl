import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "node:http";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { storage } from "./storage";
import { seed } from "./seed";
import {
  registerSchema,
  loginSchema,
  profileCompletionSchema,
  changePasswordSchema,
} from "@shared/schema";

const JWT_SECRET = process.env.SESSION_SECRET || "beauty-zone-secret-key";

function generateToken(user: any) {
  return jwt.sign(
    { id: user.id, username: user.username, role: user.role },
    JWT_SECRET,
    { expiresIn: "30d" }
  );
}

function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    (req as any).userId = decoded.id;
    (req as any).userRole = decoded.role;
    next();
  } catch {
    return res.status(401).json({ message: "Invalid token" });
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  await seed();

  app.post("/api/auth/register", async (req: Request, res: Response) => {
    try {
      const data = registerSchema.parse(req.body);
      const existing = await storage.getUserByUsername(data.username);
      if (existing) {
        return res.status(400).json({ message: "Username already taken" });
      }
      const hashedPassword = await bcrypt.hash(data.password, 12);
      const user = await storage.createUser({
        username: data.username,
        password: hashedPassword,
      });
      const token = generateToken(user);
      return res.json({
        token,
        user: {
          id: user.id,
          userIdPublic: user.userIdPublic,
          username: user.username,
          role: user.role,
          profileCompleted: user.profileCompleted,
          forcePasswordChange: user.forcePasswordChange,
          preferredLanguage: user.preferredLanguage,
        },
      });
    } catch (err: any) {
      return res.status(400).json({ message: err.message });
    }
  });

  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const data = loginSchema.parse(req.body);
      const user = await storage.getUserByUsername(data.username);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const valid = await bcrypt.compare(data.password, user.password);
      if (!valid) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      const token = generateToken(user);
      return res.json({
        token,
        user: {
          id: user.id,
          userIdPublic: user.userIdPublic,
          username: user.username,
          role: user.role,
          fullName: user.fullName,
          email: user.email,
          phoneNumber: user.phoneNumber,
          addressArea: user.addressArea,
          profileCompleted: user.profileCompleted,
          forcePasswordChange: user.forcePasswordChange,
          preferredLanguage: user.preferredLanguage,
        },
      });
    } catch (err: any) {
      return res.status(400).json({ message: err.message });
    }
  });

  app.get("/api/auth/me", authMiddleware, async (req: Request, res: Response) => {
    const user = await storage.getUser((req as any).userId);
    if (!user) return res.status(404).json({ message: "User not found" });
    return res.json({
      id: user.id,
      userIdPublic: user.userIdPublic,
      username: user.username,
      role: user.role,
      fullName: user.fullName,
      email: user.email,
      phoneNumber: user.phoneNumber,
      addressArea: user.addressArea,
      profileCompleted: user.profileCompleted,
      forcePasswordChange: user.forcePasswordChange,
      preferredLanguage: user.preferredLanguage,
    });
  });

  app.post("/api/auth/complete-profile", authMiddleware, async (req: Request, res: Response) => {
    try {
      const data = profileCompletionSchema.parse(req.body);
      const user = await storage.updateUser((req as any).userId, {
        ...data,
        profileCompleted: true,
      });
      return res.json({
        id: user!.id,
        userIdPublic: user!.userIdPublic,
        username: user!.username,
        role: user!.role,
        fullName: user!.fullName,
        email: user!.email,
        phoneNumber: user!.phoneNumber,
        addressArea: user!.addressArea,
        profileCompleted: user!.profileCompleted,
        forcePasswordChange: user!.forcePasswordChange,
        preferredLanguage: user!.preferredLanguage,
      });
    } catch (err: any) {
      return res.status(400).json({ message: err.message });
    }
  });

  app.post("/api/auth/change-password", authMiddleware, async (req: Request, res: Response) => {
    try {
      const data = changePasswordSchema.parse(req.body);
      if (data.newPassword !== data.confirmNewPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }
      const user = await storage.getUser((req as any).userId);
      if (!user) return res.status(404).json({ message: "User not found" });
      const valid = await bcrypt.compare(data.currentPassword, user.password);
      if (!valid) {
        return res.status(400).json({ message: "Current password is incorrect" });
      }
      const hashed = await bcrypt.hash(data.newPassword, 12);
      await storage.updateUser(user.id, { password: hashed, forcePasswordChange: false });
      return res.json({ message: "Password changed successfully" });
    } catch (err: any) {
      return res.status(400).json({ message: err.message });
    }
  });

  app.post("/api/auth/force-change-password", authMiddleware, async (req: Request, res: Response) => {
    try {
      const { newPassword, confirmNewPassword } = req.body;
      if (!newPassword || newPassword.length < 8) {
        return res.status(400).json({ message: "Password must be at least 8 characters" });
      }
      if (newPassword !== confirmNewPassword) {
        return res.status(400).json({ message: "Passwords do not match" });
      }
      const hashed = await bcrypt.hash(newPassword, 12);
      await storage.updateUser((req as any).userId, { password: hashed, forcePasswordChange: false });
      return res.json({ message: "Password changed successfully" });
    } catch (err: any) {
      return res.status(400).json({ message: err.message });
    }
  });

  app.put("/api/auth/language", authMiddleware, async (req: Request, res: Response) => {
    const { language } = req.body;
    if (!["ar", "en"].includes(language)) {
      return res.status(400).json({ message: "Invalid language" });
    }
    await storage.updateUser((req as any).userId, { preferredLanguage: language });
    return res.json({ message: "Language updated" });
  });

  app.get("/api/categories", async (_req: Request, res: Response) => {
    const cats = await storage.getCategories(true);
    return res.json(cats);
  });

  app.get("/api/stores", async (_req: Request, res: Response) => {
    const s = await storage.getStores(true);
    return res.json(s);
  });

  app.get("/api/stores/:id", async (req: Request, res: Response) => {
    const store = await storage.getStore(parseInt(req.params.id));
    if (!store) return res.status(404).json({ message: "Store not found" });
    return res.json(store);
  });

  app.get("/api/products", async (req: Request, res: Response) => {
    const opts: any = { activeOnly: true };
    if (req.query.categoryId) opts.categoryId = parseInt(req.query.categoryId as string);
    if (req.query.storeId) opts.storeId = parseInt(req.query.storeId as string);
    if (req.query.featured === "true") opts.featured = true;
    if (req.query.search) opts.search = req.query.search;
    if (req.query.limit) opts.limit = parseInt(req.query.limit as string);
    const prods = await storage.getProducts(opts);
    return res.json(prods);
  });

  app.get("/api/products/:id", async (req: Request, res: Response) => {
    const product = await storage.getProduct(parseInt(req.params.id));
    if (!product) return res.status(404).json({ message: "Product not found" });
    const store = await storage.getStore(product.storeId);
    return res.json({ ...product, store });
  });

  app.get("/api/home", async (_req: Request, res: Response) => {
    const [sections, banners, announcements, cats, featured] = await Promise.all([
      storage.getHomeSections(),
      storage.getAdsBanners(),
      storage.getMovingAnnouncements(),
      storage.getCategories(true),
      storage.getProducts({ featured: true, activeOnly: true, limit: 10 }),
    ]);
    return res.json({ sections, banners, announcements, categories: cats, featuredProducts: featured });
  });

  app.get("/api/ui-texts", async (_req: Request, res: Response) => {
    const texts = await storage.getUiTexts();
    return res.json(texts);
  });

  app.get("/api/settings/public", async (_req: Request, res: Response) => {
    const s = await storage.getSettings();
    return res.json({
      phoneVerificationRequired: s.phone_verification_required,
      paymentMethods: {
        bankTransfer: s.payment_bank_transfer_enabled,
        depositDelivery: s.payment_deposit_delivery_enabled,
        cashOnDelivery: s.payment_cash_on_delivery_enabled,
      },
      paymentMaintenanceMode: s.payment_maintenance_mode,
      depositPercentage: s.deposit_percentage,
      minimumDeposit: s.minimum_deposit,
      deliveryFixedFee: s.delivery_fixed_fee,
      deliveryFreeAbove: s.delivery_free_above,
      bankName: s.bank_name,
      bankAccountNumber: s.bank_account_number,
      bankAccountHolder: s.bank_account_holder,
    });
  });

  app.post("/api/orders", authMiddleware, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).userId;
      const user = await storage.getUser(userId);
      if (!user?.profileCompleted) {
        return res.status(400).json({ message: "Please complete your profile first" });
      }
      const { items, paymentMethod, deliveryAddress, notes } = req.body;
      if (!items || items.length === 0) {
        return res.status(400).json({ message: "Cart is empty" });
      }

      let subtotal = 0;
      const orderItemsData = [];
      let storeId = 0;

      for (const item of items) {
        const product = await storage.getProduct(item.productId);
        if (!product) {
          return res.status(400).json({ message: `Product ${item.productId} not found` });
        }
        storeId = product.storeId;
        const itemTotal = parseFloat(product.price) * item.quantity;
        subtotal += itemTotal;
        orderItemsData.push({
          productId: product.id,
          quantity: item.quantity,
          price: product.price,
          total: itemTotal.toFixed(2),
        });
      }

      const settingsData = await storage.getSettings();
      const deliveryFee =
        subtotal >= (settingsData.delivery_free_above || 200)
          ? 0
          : settingsData.delivery_fixed_fee || 15;
      const total = subtotal + deliveryFee;

      const commissionPercent =
        settingsData.global_commission_percent || 10;
      const commissionAmount = (total * commissionPercent) / 100;

      let status: any = "PENDING_PAYMENT";
      if (paymentMethod === "CASH_ON_DELIVERY") {
        status = "PAYMENT_CONFIRMED";
      } else if (paymentMethod === "BANK_TRANSFER") {
        status = "PENDING_RECEIPT";
      }

      const order = await storage.createOrder({
        userId,
        storeId,
        status,
        paymentMethod,
        subtotal: subtotal.toFixed(2),
        deliveryFee: deliveryFee.toFixed(2),
        total: total.toFixed(2),
        commissionAmount: commissionAmount.toFixed(2),
        deliveryAddress,
        notes,
      });

      await storage.createOrderItems(
        orderItemsData.map((item) => ({ ...item, orderId: order.id }))
      );

      return res.json(order);
    } catch (err: any) {
      return res.status(400).json({ message: err.message });
    }
  });

  app.get("/api/orders", authMiddleware, async (req: Request, res: Response) => {
    const orders = await storage.getOrdersByUser((req as any).userId);
    return res.json(orders);
  });

  app.get("/api/orders/:id", authMiddleware, async (req: Request, res: Response) => {
    const order = await storage.getOrder(parseInt(req.params.id));
    if (!order) return res.status(404).json({ message: "Order not found" });
    if (order.userId !== (req as any).userId) {
      return res.status(403).json({ message: "Forbidden" });
    }
    const items = await storage.getOrderItems(order.id);
    const productDetails = [];
    for (const item of items) {
      const product = await storage.getProduct(item.productId);
      productDetails.push({ ...item, product });
    }
    const store = await storage.getStore(order.storeId);
    return res.json({ ...order, items: productDetails, store });
  });

  app.get("/api/notifications", authMiddleware, async (req: Request, res: Response) => {
    const notifs = await storage.getNotifications((req as any).userId);
    return res.json(notifs);
  });

  app.post("/api/notifications/:id/read", authMiddleware, async (req: Request, res: Response) => {
    await storage.markNotificationRead(parseInt(req.params.id));
    return res.json({ message: "Marked as read" });
  });

  const httpServer = createServer(app);
  return httpServer;
}
