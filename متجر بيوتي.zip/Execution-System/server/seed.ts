import bcrypt from "bcryptjs";
import { db } from "./db";
import {
  users,
  categories,
  permissions,
  settings,
  homeSections,
  adsBanners,
  movingAnnouncements,
  uiTexts,
  stores,
  products,
} from "@shared/schema";
import { eq } from "drizzle-orm";

const PERMISSION_KEYS = [
  "MANAGE_USERS",
  "MANAGE_STORE_APPLICATIONS",
  "MANAGE_STORES",
  "MANAGE_PRODUCTS",
  "MANAGE_CATEGORIES",
  "MANAGE_HOME_SECTIONS",
  "MANAGE_ADS_BANNERS",
  "MANAGE_MOVING_ANNOUNCEMENTS",
  "MANAGE_ORDERS_VIEW",
  "MANAGE_ORDERS_STATUS",
  "MANAGE_PAYMENTS_REVIEW",
  "MANAGE_PAYMENTS_APPROVE",
  "MANAGE_DELIVERY",
  "MANAGE_COMMISSION",
  "MANAGE_DISCOUNTS_LOYALTY",
  "MANAGE_UI_TEXTS",
  "MANAGE_TERMS_PRIVACY",
  "MANAGE_SUPPORT_TICKETS",
  "MANAGE_ADMINS",
  "VIEW_AUDIT_LOGS",
];

export async function seed() {
  console.log("Seeding database...");

  const [existingAdmin] = await db
    .select()
    .from(users)
    .where(eq(users.username, "424230795"));

  if (!existingAdmin) {
    const hashedPassword = await bcrypt.hash("E123456kh@", 12);
    await db.insert(users).values({
      username: "424230795",
      password: hashedPassword,
      role: "MASTER_ADMIN",
      forcePasswordChange: true,
      fullName: "Master Admin",
      email: "admin@beautyzone.com",
      phoneNumber: "0000000000",
      profileCompleted: true,
    });
    console.log("Master admin seeded");
  }

  const existingPerms = await db.select().from(permissions);
  if (existingPerms.length === 0) {
    await db.insert(permissions).values(
      PERMISSION_KEYS.map((key) => ({ key, description: key.replace(/_/g, " ") }))
    );
    console.log("Permissions seeded");
  }

  const existingCats = await db.select().from(categories);
  if (existingCats.length === 0) {
    await db.insert(categories).values([
      { nameAr: "العناية بالبشرة", nameEn: "Skincare", orderIndex: 0, isActive: true, showOnHome: true },
      { nameAr: "المكياج", nameEn: "Makeup", orderIndex: 1, isActive: true, showOnHome: true },
      { nameAr: "العناية بالشعر", nameEn: "Hair Care", orderIndex: 2, isActive: true, showOnHome: true },
      { nameAr: "العطور", nameEn: "Perfumes", orderIndex: 3, isActive: true, showOnHome: true },
      { nameAr: "العناية بالجسم", nameEn: "Body Care", orderIndex: 4, isActive: true, showOnHome: true },
      { nameAr: "أظافر", nameEn: "Nails", orderIndex: 5, isActive: true, showOnHome: true },
    ]);
    console.log("Categories seeded");
  }

  const existingSettings = await db.select().from(settings);
  if (existingSettings.length === 0) {
    await db.insert(settings).values([
      { key: "phone_verification_required", valueJSON: false },
      { key: "payment_bank_transfer_enabled", valueJSON: true },
      { key: "payment_deposit_delivery_enabled", valueJSON: true },
      { key: "payment_cash_on_delivery_enabled", valueJSON: true },
      { key: "payment_maintenance_mode", valueJSON: false },
      { key: "deposit_percentage", valueJSON: 30 },
      { key: "minimum_deposit", valueJSON: 10 },
      { key: "cancellation_time_hours", valueJSON: 24 },
      { key: "global_commission_percent", valueJSON: 10 },
      { key: "delivery_fixed_fee", valueJSON: 15 },
      { key: "delivery_free_above", valueJSON: 200 },
      { key: "bank_name", valueJSON: "Bank of Palestine" },
      { key: "bank_account_number", valueJSON: "1234567890" },
      { key: "bank_account_holder", valueJSON: "Beauty Zone" },
    ]);
    console.log("Settings seeded");
  }

  const existingBanners = await db.select().from(adsBanners);
  if (existingBanners.length === 0) {
    await db.insert(adsBanners).values([
      {
        titleAr: "عروض الصيف",
        titleEn: "Summer Deals",
        imageUrlAr: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&h=400&fit=crop",
        imageUrlEn: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=800&h=400&fit=crop",
        linkType: "category",
        linkTarget: "1",
        orderIndex: 0,
        isActive: true,
      },
      {
        titleAr: "جديد المكياج",
        titleEn: "New Makeup",
        imageUrlAr: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=800&h=400&fit=crop",
        imageUrlEn: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?w=800&h=400&fit=crop",
        linkType: "category",
        linkTarget: "2",
        orderIndex: 1,
        isActive: true,
      },
    ]);
    console.log("Banners seeded");
  }

  const existingAnnouncements = await db.select().from(movingAnnouncements);
  if (existingAnnouncements.length === 0) {
    await db.insert(movingAnnouncements).values([
      {
        textAr: "مرحبا بكم في بيوتي زون - وجهتكم الأولى لمستحضرات التجميل في غزة",
        textEn: "Welcome to Beauty Zone - Your #1 destination for cosmetics in Gaza",
        isActive: true,
        speed: 50,
      },
    ]);
    console.log("Announcements seeded");
  }

  const existingHomeSections = await db.select().from(homeSections);
  if (existingHomeSections.length === 0) {
    await db.insert(homeSections).values([
      { titleAr: "التصنيفات", titleEn: "Categories", type: "category_grid", orderIndex: 0, isActive: true },
      { titleAr: "منتجات مميزة", titleEn: "Featured Products", type: "featured_products", orderIndex: 1, isActive: true },
      { titleAr: "المتاجر", titleEn: "Stores", type: "store_list", orderIndex: 2, isActive: true },
    ]);
    console.log("Home sections seeded");
  }

  const existingStores = await db.select().from(stores);
  if (existingStores.length === 0) {
    const [admin] = await db.select().from(users).where(eq(users.username, "424230795"));
    if (admin) {
      const [store1] = await db.insert(stores).values([
        {
          ownerId: admin.id,
          nameAr: "متجر الجمال",
          nameEn: "Beauty Store",
          descriptionAr: "أفضل منتجات العناية بالبشرة",
          descriptionEn: "Best skincare products",
          logoUrl: "https://images.unsplash.com/photo-1629198688000-71f23e745a41?w=200&h=200&fit=crop",
          isApproved: true,
          isActive: true,
          whatsappNumber: "+970599000000",
          bankName: "Bank of Palestine",
          bankAccountNumber: "PS12345678",
          bankAccountHolder: "Beauty Store",
        },
      ]).returning();

      const [store2] = await db.insert(stores).values([
        {
          ownerId: admin.id,
          nameAr: "عالم العطور",
          nameEn: "Perfume World",
          descriptionAr: "أفخم العطور العالمية",
          descriptionEn: "Finest international perfumes",
          logoUrl: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=200&h=200&fit=crop",
          isApproved: true,
          isActive: true,
          whatsappNumber: "+970599111111",
          bankName: "Bank of Palestine",
          bankAccountNumber: "PS98765432",
          bankAccountHolder: "Perfume World",
        },
      ]).returning();

      if (store1 && store2) {
        await db.insert(products).values([
          {
            storeId: store1.id,
            categoryId: 1,
            nameAr: "كريم ترطيب يومي",
            nameEn: "Daily Moisturizer",
            descriptionAr: "كريم مرطب خفيف للاستخدام اليومي",
            descriptionEn: "Light moisturizing cream for daily use",
            price: "45.00",
            originalPrice: "60.00",
            images: ["https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop"],
            stock: 25,
            isActive: true,
            isFeatured: true,
            suitableFor: "All skin types",
            ingredients: "Hyaluronic Acid, Vitamin E, Aloe Vera",
          },
          {
            storeId: store1.id,
            categoryId: 1,
            nameAr: "سيروم فيتامين سي",
            nameEn: "Vitamin C Serum",
            descriptionAr: "سيروم مضيء للبشرة بفيتامين سي",
            descriptionEn: "Brightening vitamin C serum for glowing skin",
            price: "89.00",
            images: ["https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400&h=400&fit=crop"],
            stock: 15,
            isActive: true,
            isFeatured: true,
            suitableFor: "Normal, Combination",
            ingredients: "Vitamin C 20%, Ferulic Acid, Vitamin E",
          },
          {
            storeId: store1.id,
            categoryId: 2,
            nameAr: "أحمر شفاه مات",
            nameEn: "Matte Lipstick",
            descriptionAr: "أحمر شفاه مات يدوم طويلا",
            descriptionEn: "Long-lasting matte lipstick",
            price: "35.00",
            images: ["https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=400&h=400&fit=crop"],
            stock: 40,
            isActive: true,
            isFeatured: true,
          },
          {
            storeId: store1.id,
            categoryId: 3,
            nameAr: "شامبو أرغان",
            nameEn: "Argan Shampoo",
            descriptionAr: "شامبو بزيت الأرغان للشعر التالف",
            descriptionEn: "Argan oil shampoo for damaged hair",
            price: "55.00",
            images: ["https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=400&h=400&fit=crop"],
            stock: 30,
            isActive: true,
            isFeatured: false,
          },
          {
            storeId: store2.id,
            categoryId: 4,
            nameAr: "عطر ورد",
            nameEn: "Rose Perfume",
            descriptionAr: "عطر وردي فاخر طويل الأمد",
            descriptionEn: "Luxury long-lasting rose perfume",
            price: "120.00",
            originalPrice: "150.00",
            images: ["https://images.unsplash.com/photo-1541643600914-78b084683601?w=400&h=400&fit=crop"],
            stock: 10,
            isActive: true,
            isFeatured: true,
          },
          {
            storeId: store2.id,
            categoryId: 5,
            nameAr: "لوشن جسم",
            nameEn: "Body Lotion",
            descriptionAr: "لوشن مرطب للجسم برائحة اللافندر",
            descriptionEn: "Moisturizing body lotion with lavender scent",
            price: "38.00",
            images: ["https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=400&h=400&fit=crop"],
            stock: 20,
            isActive: true,
            isFeatured: true,
          },
        ]);
        console.log("Demo stores and products seeded");
      }
    }
  }

  const existingTexts = await db.select().from(uiTexts);
  if (existingTexts.length === 0) {
    await db.insert(uiTexts).values([
      { key: "app_name", ar: "بيوتي زون", en: "Beauty Zone" },
      { key: "home", ar: "الرئيسية", en: "Home" },
      { key: "categories", ar: "التصنيفات", en: "Categories" },
      { key: "stores", ar: "المتاجر", en: "Stores" },
      { key: "cart", ar: "السلة", en: "Cart" },
      { key: "settings", ar: "الإعدادات", en: "Settings" },
      { key: "login", ar: "تسجيل الدخول", en: "Login" },
      { key: "register", ar: "إنشاء حساب", en: "Register" },
      { key: "search", ar: "بحث", en: "Search" },
      { key: "orders", ar: "طلباتي", en: "My Orders" },
      { key: "profile", ar: "الملف الشخصي", en: "Profile" },
      { key: "notifications", ar: "الإشعارات", en: "Notifications" },
      { key: "support", ar: "الدعم", en: "Support" },
      { key: "add_to_cart", ar: "أضف للسلة", en: "Add to Cart" },
      { key: "checkout", ar: "إتمام الطلب", en: "Checkout" },
      { key: "featured_products", ar: "منتجات مميزة", en: "Featured Products" },
      { key: "see_all", ar: "عرض الكل", en: "See All" },
      { key: "welcome", ar: "مرحبا", en: "Welcome" },
      { key: "language", ar: "اللغة", en: "Language" },
      { key: "change_password", ar: "تغيير كلمة المرور", en: "Change Password" },
    ]);
    console.log("UI texts seeded");
  }

  console.log("Seeding complete!");
}
