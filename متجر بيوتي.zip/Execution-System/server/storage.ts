import { db } from "./db";
import { eq, and, desc, asc, ilike, sql, inArray, isNull, lte, or } from "drizzle-orm";
import {
  users,
  categories,
  stores,
  products,
  orders,
  orderItems,
  homeSections,
  adsBanners,
  movingAnnouncements,
  uiTexts,
  settings,
  notifications,
  tickets,
  ticketMessages,
  permissions,
  adminUserPermissions,
  auditLogs,
  type User,
  type InsertUser,
  type Category,
  type Store,
  type Product,
  type Order,
} from "@shared/schema";

export const storage = {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  },

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  },

  async createUser(data: {
    username: string;
    password: string;
    role?: string;
    forcePasswordChange?: boolean;
  }): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        username: data.username,
        password: data.password,
        role: (data.role as any) || "USER",
        forcePasswordChange: data.forcePasswordChange || false,
      })
      .returning();
    return user;
  },

  async updateUser(
    id: string,
    data: Partial<{
      fullName: string;
      email: string;
      phoneNumber: string;
      addressArea: string;
      profileCompleted: boolean;
      password: string;
      forcePasswordChange: boolean;
      preferredLanguage: string;
    }>
  ): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  },

  async getCategories(activeOnly = false): Promise<Category[]> {
    const query = activeOnly
      ? db
          .select()
          .from(categories)
          .where(eq(categories.isActive, true))
          .orderBy(asc(categories.orderIndex))
      : db.select().from(categories).orderBy(asc(categories.orderIndex));
    return query;
  },

  async getCategory(id: number): Promise<Category | undefined> {
    const [cat] = await db
      .select()
      .from(categories)
      .where(eq(categories.id, id));
    return cat;
  },

  async getStores(activeOnly = false): Promise<Store[]> {
    if (activeOnly) {
      return db
        .select()
        .from(stores)
        .where(and(eq(stores.isActive, true), eq(stores.isApproved, true)));
    }
    return db.select().from(stores);
  },

  async getStore(id: number): Promise<Store | undefined> {
    const [store] = await db
      .select()
      .from(stores)
      .where(eq(stores.id, id));
    return store;
  },

  async getProducts(opts?: {
    categoryId?: number;
    storeId?: number;
    featured?: boolean;
    activeOnly?: boolean;
    search?: string;
    limit?: number;
  }): Promise<Product[]> {
    const conditions = [];
    if (opts?.activeOnly) conditions.push(eq(products.isActive, true));
    if (opts?.categoryId) conditions.push(eq(products.categoryId, opts.categoryId));
    if (opts?.storeId) conditions.push(eq(products.storeId, opts.storeId));
    if (opts?.featured) conditions.push(eq(products.isFeatured, true));
    if (opts?.search) {
      conditions.push(
        or(
          ilike(products.nameAr, `%${opts.search}%`),
          ilike(products.nameEn, `%${opts.search}%`)
        )!
      );
    }

    let query = db
      .select()
      .from(products)
      .orderBy(desc(products.createdAt));

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    if (opts?.limit) {
      query = query.limit(opts.limit) as any;
    }
    return query;
  },

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db
      .select()
      .from(products)
      .where(eq(products.id, id));
    return product;
  },

  async getHomeSections(): Promise<any[]> {
    return db
      .select()
      .from(homeSections)
      .where(eq(homeSections.isActive, true))
      .orderBy(asc(homeSections.orderIndex));
  },

  async getAdsBanners(): Promise<any[]> {
    const now = new Date();
    return db
      .select()
      .from(adsBanners)
      .where(eq(adsBanners.isActive, true))
      .orderBy(asc(adsBanners.orderIndex));
  },

  async getMovingAnnouncements(): Promise<any[]> {
    return db
      .select()
      .from(movingAnnouncements)
      .where(eq(movingAnnouncements.isActive, true));
  },

  async getUiTexts(): Promise<Record<string, { ar: string; en: string }>> {
    const rows = await db.select().from(uiTexts);
    const map: Record<string, { ar: string; en: string }> = {};
    for (const r of rows) {
      map[r.key] = { ar: r.ar, en: r.en };
    }
    return map;
  },

  async getSetting(key: string): Promise<any> {
    const [row] = await db
      .select()
      .from(settings)
      .where(eq(settings.key, key));
    return row?.valueJSON;
  },

  async getSettings(): Promise<Record<string, any>> {
    const rows = await db.select().from(settings);
    const map: Record<string, any> = {};
    for (const r of rows) {
      map[r.key] = r.valueJSON;
    }
    return map;
  },

  async createOrder(data: any): Promise<Order> {
    const [order] = await db.insert(orders).values(data).returning();
    return order;
  },

  async createOrderItems(items: any[]): Promise<void> {
    await db.insert(orderItems).values(items);
  },

  async getOrdersByUser(userId: string): Promise<Order[]> {
    return db
      .select()
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.createdAt));
  },

  async getOrder(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  },

  async getOrderItems(orderId: number) {
    return db
      .select()
      .from(orderItems)
      .where(eq(orderItems.orderId, orderId));
  },

  async updateOrder(id: number, data: Partial<Order>): Promise<Order | undefined> {
    const [order] = await db
      .update(orders)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(orders.id, id))
      .returning();
    return order;
  },

  async getNotifications(userId: string) {
    return db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  },

  async createNotification(data: any) {
    const [notif] = await db.insert(notifications).values(data).returning();
    return notif;
  },

  async markNotificationRead(id: number) {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  },

  async createAuditLog(data: any) {
    await db.insert(auditLogs).values(data);
  },
};
