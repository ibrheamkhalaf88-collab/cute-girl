import { StyleSheet, Text, View, ScrollView, Pressable, ActivityIndicator, Dimensions, Platform } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language-context";
import { useCart } from "@/lib/cart-context";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

export default function ProductDetailScreen() {
  const { id } = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { addItem } = useCart();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: product, isLoading } = useQuery({
    queryKey: ["/api/products", id],
  });

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!product) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textSecondary }}>Product not found</Text>
      </View>
    );
  }

  const handleAdd = () => {
    addItem({
      productId: product.id,
      nameAr: product.nameAr,
      nameEn: product.nameEn,
      price: product.price,
      image: product.images?.[0] || "",
      storeId: product.storeId,
      storeNameAr: product.store?.nameAr || "",
      storeNameEn: product.store?.nameEn || "",
    });
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const discount = product.originalPrice
    ? Math.round((1 - parseFloat(product.price) / parseFloat(product.originalPrice)) * 100)
    : 0;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <Pressable
        onPress={() => router.back()}
        style={[styles.backButton, { top: insets.top + webTopInset + 8, backgroundColor: colors.card + "CC" }]}
      >
        <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={22} color={colors.text} />
      </Pressable>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 120 }}>
        <Image
          source={{ uri: product.images?.[0] }}
          style={styles.productImage}
          contentFit="cover"
        />

        {discount > 0 && (
          <View style={[styles.discountBadge, { backgroundColor: colors.error }]}>
            <Text style={styles.discountText}>-{discount}%</Text>
          </View>
        )}

        <View style={styles.detailsContainer}>
          <Text style={[styles.productName, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {lang === "ar" ? product.nameAr : product.nameEn}
          </Text>

          {product.store && (
            <Pressable
              style={[styles.storeRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}
              onPress={() => router.push(`/store/${product.storeId}`)}
            >
              <Ionicons name="storefront-outline" size={14} color={colors.primary} />
              <Text style={[styles.storeName, { color: colors.primary }]}>
                {lang === "ar" ? product.store.nameAr : product.store.nameEn}
              </Text>
            </Pressable>
          )}

          <View style={[styles.priceRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Text style={[styles.price, { color: colors.primary }]}>
              {t("shekel")}{product.price}
            </Text>
            {product.originalPrice && (
              <Text style={[styles.originalPrice, { color: colors.textSecondary }]}>
                {t("shekel")}{product.originalPrice}
              </Text>
            )}
          </View>

          {(product.descriptionAr || product.descriptionEn) && (
            <View style={styles.infoSection}>
              <Text style={[styles.infoTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
                {t("product_details")}
              </Text>
              <Text style={[styles.infoText, { color: colors.textSecondary, textAlign: isRTL ? "right" : "left" }]}>
                {lang === "ar" ? product.descriptionAr : product.descriptionEn}
              </Text>
            </View>
          )}

          {product.suitableFor && (
            <InfoRow icon="body-outline" label={t("suitable_for")} value={product.suitableFor} colors={colors} isRTL={isRTL} />
          )}
          {product.ingredients && (
            <InfoRow icon="leaf-outline" label={t("ingredients")} value={product.ingredients} colors={colors} isRTL={isRTL} />
          )}
          {product.howToUse && (
            <InfoRow icon="hand-left-outline" label={t("how_to_use")} value={product.howToUse} colors={colors} isRTL={isRTL} />
          )}
          {product.warnings && (
            <InfoRow icon="warning-outline" label={t("warnings_label")} value={product.warnings} colors={colors} isRTL={isRTL} />
          )}
        </View>
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: colors.card, paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 0) + 12 }]}>
        <View style={{ flex: 1 }}>
          <Text style={[styles.footerPrice, { color: colors.primary }]}>
            {t("shekel")}{product.price}
          </Text>
        </View>
        <Pressable style={[styles.addToCartBtn, { backgroundColor: colors.primary }]} onPress={handleAdd}>
          <Ionicons name="bag-add" size={18} color="#FFF" />
          <Text style={styles.addToCartText}>{t("add_to_cart")}</Text>
        </Pressable>
      </View>
    </View>
  );
}

function InfoRow({ icon, label, value, colors, isRTL }: any) {
  return (
    <View style={[styles.infoSection, { borderTopWidth: 1, borderTopColor: colors.border, paddingTop: 14 }]}>
      <View style={[styles.infoHeaderRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
        <Ionicons name={icon} size={16} color={colors.primary} />
        <Text style={[styles.infoTitle, { color: colors.text }]}>{label}</Text>
      </View>
      <Text style={[styles.infoText, { color: colors.textSecondary, textAlign: isRTL ? "right" : "left" }]}>
        {value}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  backButton: {
    position: "absolute",
    left: 16,
    zIndex: 10,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  productImage: { width: SCREEN_WIDTH, height: SCREEN_WIDTH * 0.85 },
  discountBadge: {
    position: "absolute",
    top: 16,
    right: 16,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  discountText: { fontFamily: "Cairo_700Bold", fontSize: 13, color: "#FFF" },
  detailsContainer: { padding: 20, gap: 12 },
  productName: { fontFamily: "Cairo_700Bold", fontSize: 22, lineHeight: 32 },
  storeRow: { alignItems: "center", gap: 6 },
  storeName: { fontFamily: "Cairo_600SemiBold", fontSize: 13 },
  priceRow: { alignItems: "baseline", gap: 10 },
  price: { fontFamily: "Cairo_700Bold", fontSize: 24 },
  originalPrice: { fontFamily: "Cairo_400Regular", fontSize: 16, textDecorationLine: "line-through" as const },
  infoSection: { gap: 6 },
  infoHeaderRow: { alignItems: "center", gap: 6 },
  infoTitle: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  infoText: { fontFamily: "Cairo_400Regular", fontSize: 14, lineHeight: 22 },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 14,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 4,
  },
  footerPrice: { fontFamily: "Cairo_700Bold", fontSize: 22 },
  addToCartBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 13,
    borderRadius: 14,
    gap: 8,
  },
  addToCartText: { fontFamily: "Cairo_700Bold", fontSize: 14, color: "#FFF" },
});
