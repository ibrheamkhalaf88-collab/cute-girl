import { StyleSheet, Text, View, ScrollView, Pressable, Alert, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function AccountScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t, setLanguage } = useLanguage();
  const { user, logout } = useAuth();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const handleLogout = () => {
    Alert.alert(
      t("logout"),
      lang === "ar" ? "هل أنت متأكد؟" : "Are you sure?",
      [
        { text: lang === "ar" ? "إلغاء" : "Cancel", style: "cancel" },
        {
          text: t("logout"),
          style: "destructive",
          onPress: async () => {
            await logout();
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          },
        },
      ]
    );
  };

  const toggleLanguage = async () => {
    const newLang = lang === "ar" ? "en" : "ar";
    await setLanguage(newLang);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  if (!user) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}>
          <Text style={[styles.headerTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("account")}
          </Text>
        </View>
        <View style={styles.emptyContainer}>
          <View style={[styles.avatarCircle, { backgroundColor: colors.primaryLight }]}>
            <Ionicons name="person" size={40} color={colors.primary} />
          </View>
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            {lang === "ar" ? "سجل دخولك لإدارة حسابك" : "Sign in to manage your account"}
          </Text>
          <Pressable
            style={[styles.loginBtn, { backgroundColor: colors.primary }]}
            onPress={() => router.push("/(auth)/login")}
          >
            <Text style={styles.loginBtnText}>{t("login")}</Text>
          </Pressable>
        </View>
        <View style={[styles.section, { paddingBottom: 100 }]}>
          <MenuItem
            icon="language-outline"
            label={t("language")}
            value={lang === "ar" ? "العربية" : "English"}
            onPress={toggleLanguage}
            colors={colors}
            isRTL={isRTL}
          />
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 120 }}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}>
          <Text style={[styles.headerTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("account")}
          </Text>
        </View>

        <View style={[styles.profileCard, { backgroundColor: colors.card, flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <View style={[styles.avatarCircle, { backgroundColor: colors.primaryLight }]}>
            <Text style={[styles.avatarText, { color: colors.primary }]}>
              {(user.fullName || user.username).charAt(0).toUpperCase()}
            </Text>
          </View>
          <View style={[styles.profileInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
            <Text style={[styles.profileName, { color: colors.text }]}>
              {user.fullName || user.username}
            </Text>
            <Text style={[styles.profileEmail, { color: colors.textSecondary }]}>
              {user.email || user.username}
            </Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionLabel, { color: colors.textSecondary, textAlign: isRTL ? "right" : "left" }]}>
            {t("user_id")}
          </Text>
          <View style={[styles.idCard, { backgroundColor: colors.inputBg }]}>
            <Text style={[styles.idText, { color: colors.text }]}>{user.userIdPublic}</Text>
          </View>
        </View>

        <View style={styles.section}>
          {!user.profileCompleted && (
            <MenuItem
              icon="person-circle-outline"
              label={t("complete_profile")}
              onPress={() => router.push("/complete-profile")}
              colors={colors}
              isRTL={isRTL}
              highlight
            />
          )}
          <MenuItem
            icon="language-outline"
            label={t("language")}
            value={lang === "ar" ? "العربية" : "English"}
            onPress={toggleLanguage}
            colors={colors}
            isRTL={isRTL}
          />
          <MenuItem
            icon="lock-closed-outline"
            label={t("change_password")}
            onPress={() => router.push("/change-password")}
            colors={colors}
            isRTL={isRTL}
          />
          <MenuItem
            icon="notifications-outline"
            label={t("notifications")}
            onPress={() => {}}
            colors={colors}
            isRTL={isRTL}
          />
          <MenuItem
            icon="help-circle-outline"
            label={t("support")}
            onPress={() => {}}
            colors={colors}
            isRTL={isRTL}
          />
        </View>

        <Pressable style={[styles.logoutBtn, { borderColor: colors.error }]} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={20} color={colors.error} />
          <Text style={[styles.logoutText, { color: colors.error }]}>{t("logout")}</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

function MenuItem({
  icon,
  label,
  value,
  onPress,
  colors,
  isRTL,
  highlight,
}: {
  icon: string;
  label: string;
  value?: string;
  onPress: () => void;
  colors: any;
  isRTL: boolean;
  highlight?: boolean;
}) {
  return (
    <Pressable
      style={[
        styles.menuItem,
        {
          backgroundColor: highlight ? colors.primaryLight : colors.card,
          flexDirection: isRTL ? "row-reverse" : "row",
        },
      ]}
      onPress={onPress}
    >
      <Ionicons name={icon as any} size={20} color={highlight ? colors.primary : colors.textSecondary} />
      <Text style={[styles.menuLabel, { color: colors.text, flex: 1, textAlign: isRTL ? "right" : "left" }]}>
        {label}
      </Text>
      {value && <Text style={[styles.menuValue, { color: colors.textSecondary }]}>{value}</Text>}
      <Ionicons
        name={isRTL ? "chevron-back" : "chevron-forward"}
        size={16}
        color={colors.textSecondary}
      />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 8 },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 26 },
  emptyContainer: { alignItems: "center", gap: 10, paddingVertical: 40 },
  emptyText: { fontFamily: "Cairo_600SemiBold", fontSize: 15 },
  loginBtn: { paddingHorizontal: 32, paddingVertical: 12, borderRadius: 12, marginTop: 4 },
  loginBtnText: { fontFamily: "Cairo_700Bold", fontSize: 14, color: "#FFF" },
  profileCard: {
    marginHorizontal: 20,
    padding: 16,
    borderRadius: 20,
    alignItems: "center",
    gap: 14,
    marginBottom: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.04,
    shadowRadius: 8,
    elevation: 1,
  },
  avatarCircle: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarText: { fontFamily: "Cairo_700Bold", fontSize: 24 },
  profileInfo: { flex: 1, gap: 2 },
  profileName: { fontFamily: "Cairo_700Bold", fontSize: 17 },
  profileEmail: { fontFamily: "Cairo_400Regular", fontSize: 13 },
  section: { paddingHorizontal: 20, gap: 8, marginBottom: 20 },
  sectionLabel: { fontFamily: "Cairo_600SemiBold", fontSize: 12, marginBottom: 4 },
  idCard: { paddingHorizontal: 16, paddingVertical: 12, borderRadius: 12, alignItems: "center" },
  idText: { fontFamily: "Cairo_700Bold", fontSize: 16, letterSpacing: 1 },
  menuItem: {
    padding: 14,
    borderRadius: 14,
    alignItems: "center",
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.02,
    shadowRadius: 2,
    elevation: 1,
  },
  menuLabel: { fontFamily: "Cairo_600SemiBold", fontSize: 14 },
  menuValue: { fontFamily: "Cairo_400Regular", fontSize: 13 },
  logoutBtn: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1.5,
    gap: 8,
    marginTop: 8,
  },
  logoutText: { fontFamily: "Cairo_700Bold", fontSize: 14 },
});
