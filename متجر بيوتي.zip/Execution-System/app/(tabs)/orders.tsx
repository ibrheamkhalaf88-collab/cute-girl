import { StyleSheet, Text, View, FlatList, Pressable, ActivityIndicator, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";
import Colors from "@/constants/colors";

const STATUS_COLORS: Record<string, string> = {
  PENDING_PAYMENT: "#F59E0B",
  PENDING_RECEIPT: "#F59E0B",
  PENDING_ADMIN_REVIEW: "#3B82F6",
  PAYMENT_CONFIRMED: "#10B981",
  PREPARING: "#8B5CF6",
  READY: "#06B6D4",
  OUT_FOR_DELIVERY: "#F97316",
  DELIVERED: "#22C55E",
  CANCELLED: "#EF4444",
  REJECTED: "#EF4444",
};

const STATUS_LABELS: Record<string, { ar: string; en: string }> = {
  PENDING_PAYMENT: { ar: "بانتظار الدفع", en: "Pending Payment" },
  PENDING_RECEIPT: { ar: "بانتظار الإيصال", en: "Upload Receipt" },
  PENDING_ADMIN_REVIEW: { ar: "قيد المراجعة", en: "Under Review" },
  PAYMENT_CONFIRMED: { ar: "تم تأكيد الدفع", en: "Payment Confirmed" },
  PREPARING: { ar: "جاري التحضير", en: "Preparing" },
  READY: { ar: "جاهز للتوصيل", en: "Ready" },
  OUT_FOR_DELIVERY: { ar: "في الطريق", en: "Out for Delivery" },
  DELIVERED: { ar: "تم التوصيل", en: "Delivered" },
  CANCELLED: { ar: "ملغي", en: "Cancelled" },
  REJECTED: { ar: "مرفوض", en: "Rejected" },
};

export default function OrdersScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { user, token } = useAuth();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: orders, isLoading } = useQuery({
    queryKey: ["/api/orders"],
    queryFn: async () => {
      if (!token) return [];
      const baseUrl = getApiUrl();
      const url = new URL("/api/orders", baseUrl);
      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return [];
      return res.json();
    },
    enabled: !!token,
  });

  if (!user) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}>
          <Text style={[styles.headerTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("orders")}
          </Text>
        </View>
        <View style={styles.emptyContainer}>
          <Ionicons name="log-in-outline" size={56} color={colors.border} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
            {lang === "ar" ? "سجل دخولك لعرض طلباتك" : "Sign in to view your orders"}
          </Text>
          <Pressable
            style={[styles.loginBtn, { backgroundColor: colors.primary }]}
            onPress={() => router.push("/(auth)/login")}
          >
            <Text style={styles.loginBtnText}>{t("login")}</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const renderOrder = ({ item }: any) => {
    const statusColor = STATUS_COLORS[item.status] || "#6B7280";
    const statusLabel = STATUS_LABELS[item.status]?.[lang] || item.status;
    return (
      <Pressable
        style={[styles.orderCard, { backgroundColor: colors.card, flexDirection: isRTL ? "row-reverse" : "row" }]}
        onPress={() => router.push(`/order/${item.id}`)}
      >
        <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
        <View style={[styles.orderInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
          <Text style={[styles.orderNumber, { color: colors.text }]}>{item.orderNumber}</Text>
          <Text style={[styles.orderStatus, { color: statusColor }]}>{statusLabel}</Text>
          <Text style={[styles.orderTotal, { color: colors.textSecondary }]}>
            {t("shekel")}{item.total}
          </Text>
        </View>
        <Ionicons
          name={isRTL ? "chevron-back" : "chevron-forward"}
          size={18}
          color={colors.textSecondary}
        />
      </Pressable>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}>
        <Text style={[styles.headerTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
          {t("orders")}
        </Text>
      </View>

      {isLoading ? (
        <View style={styles.emptyContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (!orders || orders.length === 0) ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="receipt-outline" size={56} color={colors.border} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t("no_orders")}</Text>
        </View>
      ) : (
        <FlatList
          data={orders}
          renderItem={renderOrder}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          contentInsetAdjustmentBehavior="automatic"
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 8 },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 26 },
  emptyContainer: { flex: 1, justifyContent: "center", alignItems: "center", gap: 10 },
  emptyText: { fontFamily: "Cairo_600SemiBold", fontSize: 15 },
  loginBtn: { paddingHorizontal: 24, paddingVertical: 10, borderRadius: 12, marginTop: 8 },
  loginBtnText: { fontFamily: "Cairo_700Bold", fontSize: 14, color: "#FFF" },
  listContent: { padding: 16, gap: 10, paddingBottom: 100 },
  orderCard: {
    padding: 14,
    borderRadius: 16,
    alignItems: "center",
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  statusDot: { width: 10, height: 10, borderRadius: 5 },
  orderInfo: { flex: 1, gap: 2 },
  orderNumber: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  orderStatus: { fontFamily: "Cairo_600SemiBold", fontSize: 12 },
  orderTotal: { fontFamily: "Cairo_400Regular", fontSize: 13 },
});
