import { StyleSheet, Text, View, FlatList, Pressable, Platform } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useCart } from "@/lib/cart-context";
import { useAuth } from "@/lib/auth-context";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function CartScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { items, removeItem, updateQuantity, subtotal, totalItems } = useCart();
  const { user } = useAuth();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const handleCheckout = () => {
    if (!user) {
      router.push("/(auth)/login");
      return;
    }
    if (!user.profileCompleted) {
      router.push("/complete-profile");
      return;
    }
    router.push("/checkout");
  };

  const renderItem = ({ item }: any) => (
    <View style={[styles.cartItem, { backgroundColor: colors.card, flexDirection: isRTL ? "row-reverse" : "row" }]}>
      <Image source={{ uri: item.image }} style={styles.itemImage} contentFit="cover" />
      <View style={[styles.itemInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
        <Text style={[styles.itemName, { color: colors.text }]} numberOfLines={2}>
          {lang === "ar" ? item.nameAr : item.nameEn}
        </Text>
        <Text style={[styles.itemPrice, { color: colors.primary }]}>
          {t("shekel")}{item.price}
        </Text>
        <View style={[styles.qtyRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <Pressable
            onPress={() => {
              updateQuantity(item.productId, item.quantity - 1);
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={[styles.qtyBtn, { backgroundColor: colors.inputBg }]}
          >
            <Ionicons name="remove" size={16} color={colors.text} />
          </Pressable>
          <Text style={[styles.qtyText, { color: colors.text }]}>{item.quantity}</Text>
          <Pressable
            onPress={() => {
              updateQuantity(item.productId, item.quantity + 1);
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }}
            style={[styles.qtyBtn, { backgroundColor: colors.inputBg }]}
          >
            <Ionicons name="add" size={16} color={colors.text} />
          </Pressable>
        </View>
      </View>
      <Pressable
        onPress={() => {
          removeItem(item.productId);
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        }}
        style={styles.removeBtn}
      >
        <Ionicons name="trash-outline" size={18} color={colors.error} />
      </Pressable>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}>
        <Text style={[styles.headerTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
          {t("cart")} {totalItems > 0 && `(${totalItems})`}
        </Text>
      </View>

      {items.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="bag-outline" size={64} color={colors.border} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t("empty_cart")}</Text>
          <Pressable
            style={[styles.continueBtn, { backgroundColor: colors.primary }]}
            onPress={() => router.push("/(tabs)/explore")}
          >
            <Text style={styles.continueBtnText}>{t("continue_shopping")}</Text>
          </Pressable>
        </View>
      ) : (
        <>
          <FlatList
            data={items}
            renderItem={renderItem}
            keyExtractor={(item) => String(item.productId)}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            contentInsetAdjustmentBehavior="automatic"
          />
          <View style={[styles.footer, { backgroundColor: colors.card, paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 0) + 80 }]}>
            <View style={[styles.totalRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
              <Text style={[styles.totalLabel, { color: colors.textSecondary }]}>{t("subtotal")}</Text>
              <Text style={[styles.totalValue, { color: colors.text }]}>
                {t("shekel")}{subtotal.toFixed(2)}
              </Text>
            </View>
            <Pressable
              style={[styles.checkoutBtn, { backgroundColor: colors.primary }]}
              onPress={handleCheckout}
            >
              <Text style={styles.checkoutBtnText}>{t("checkout")}</Text>
              <Ionicons name={isRTL ? "arrow-back" : "arrow-forward"} size={18} color="#FFF" />
            </Pressable>
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 8 },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 26 },
  emptyContainer: { flex: 1, justifyContent: "center", alignItems: "center", gap: 12 },
  emptyText: { fontFamily: "Cairo_600SemiBold", fontSize: 16, marginTop: 8 },
  continueBtn: { paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8 },
  continueBtnText: { fontFamily: "Cairo_700Bold", fontSize: 14, color: "#FFF" },
  listContent: { padding: 16, gap: 10, paddingBottom: 240 },
  cartItem: {
    padding: 12,
    borderRadius: 16,
    gap: 12,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  itemImage: { width: 80, height: 80, borderRadius: 12 },
  itemInfo: { flex: 1, gap: 4 },
  itemName: { fontFamily: "Cairo_600SemiBold", fontSize: 14, lineHeight: 20 },
  itemPrice: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  qtyRow: { alignItems: "center", gap: 12, marginTop: 4 },
  qtyBtn: { width: 30, height: 30, borderRadius: 10, justifyContent: "center", alignItems: "center" },
  qtyText: { fontFamily: "Cairo_700Bold", fontSize: 15, minWidth: 20, textAlign: "center" },
  removeBtn: { padding: 6 },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    gap: 12,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 4,
  },
  totalRow: { justifyContent: "space-between", alignItems: "center" },
  totalLabel: { fontFamily: "Cairo_600SemiBold", fontSize: 15 },
  totalValue: { fontFamily: "Cairo_700Bold", fontSize: 20 },
  checkoutBtn: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 14,
    borderRadius: 14,
    gap: 8,
  },
  checkoutBtnText: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "#FFF" },
});
