import { useEffect, useRef, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Pressable,
  Dimensions,
  ActivityIndicator,
  Platform,
  FlatList,
  Animated as RNAnimated,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons, Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";
import Colors from "@/constants/colors";

const { width: SCREEN_WIDTH } = Dimensions.get("window");

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { user } = useAuth();
  const { addItem } = useCart();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: homeData, isLoading } = useQuery({
    queryKey: ["/api/home"],
  });

  const scrollX = useRef(new RNAnimated.Value(0)).current;
  const bannerRef = useRef<FlatList>(null);
  const [currentBanner, setCurrentBanner] = useState(0);

  const banners = homeData?.banners || [];
  const announcements = homeData?.announcements || [];
  const cats = homeData?.categories || [];
  const featured = homeData?.featuredProducts || [];

  useEffect(() => {
    if (banners.length <= 1) return;
    const interval = setInterval(() => {
      const next = (currentBanner + 1) % banners.length;
      setCurrentBanner(next);
      bannerRef.current?.scrollToIndex({ index: next, animated: true });
    }, 4000);
    return () => clearInterval(interval);
  }, [currentBanner, banners.length]);

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  const renderBanner = ({ item }: any) => (
    <Pressable style={styles.bannerItem} onPress={() => {
      if (item.linkType === "category") router.push(`/category/${item.linkTarget}`);
    }}>
      <Image
        source={{ uri: lang === "ar" ? item.imageUrlAr : item.imageUrlEn }}
        style={styles.bannerImage}
        contentFit="cover"
      />
      <View style={styles.bannerOverlay}>
        <Text style={[styles.bannerTitle, { textAlign: isRTL ? "right" : "left" }]}>
          {lang === "ar" ? item.titleAr : item.titleEn}
        </Text>
      </View>
    </Pressable>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 12 }]}>
          <View style={[styles.headerRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.greeting, { textAlign: isRTL ? "right" : "left", color: colors.textSecondary }]}>
                {t("welcome")}
              </Text>
              <Text style={[styles.headerTitle, { textAlign: isRTL ? "right" : "left", color: colors.text }]}>
                {user?.fullName || t("app_name")}
              </Text>
            </View>
            <Pressable onPress={() => router.push("/search")} style={[styles.searchIconBtn, { backgroundColor: colors.inputBg }]}>
              <Ionicons name="search" size={20} color={colors.textSecondary} />
            </Pressable>
          </View>
        </View>

        {announcements.length > 0 && (
          <MarqueeAnnouncement
            text={lang === "ar" ? announcements[0].textAr : announcements[0].textEn}
            color={colors.primary}
            isRTL={isRTL}
          />
        )}

        {banners.length > 0 && (
          <View style={styles.bannerSection}>
            <FlatList
              ref={bannerRef}
              data={banners}
              renderItem={renderBanner}
              keyExtractor={(item) => String(item.id)}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              onScroll={RNAnimated.event(
                [{ nativeEvent: { contentOffset: { x: scrollX } } }],
                { useNativeDriver: false }
              )}
              onMomentumScrollEnd={(e) => {
                setCurrentBanner(Math.round(e.nativeEvent.contentOffset.x / (SCREEN_WIDTH - 32)));
              }}
            />
            {banners.length > 1 && (
              <View style={styles.dotsContainer}>
                {banners.map((_: any, i: number) => (
                  <View
                    key={i}
                    style={[
                      styles.dot,
                      { backgroundColor: i === currentBanner ? colors.primary : colors.border },
                    ]}
                  />
                ))}
              </View>
            )}
          </View>
        )}

        {cats.length > 0 && (
          <View style={styles.section}>
            <View style={[styles.sectionHeader, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>{t("categories")}</Text>
              <Pressable onPress={() => router.push("/(tabs)/explore")}>
                <Text style={[styles.seeAll, { color: colors.primary }]}>{t("see_all")}</Text>
              </Pressable>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.categoriesRow}
              style={isRTL ? { transform: [{ scaleX: -1 }] } : undefined}
            >
              {cats.map((cat: any) => (
                <Pressable
                  key={cat.id}
                  style={[styles.categoryCard, isRTL ? { transform: [{ scaleX: -1 }] } : undefined]}
                  onPress={() => router.push(`/category/${cat.id}`)}
                >
                  <View style={[styles.categoryIconContainer, { backgroundColor: colors.primaryLight }]}>
                    <Ionicons name="sparkles" size={22} color={colors.primary} />
                  </View>
                  <Text style={[styles.categoryName, { color: colors.text }]} numberOfLines={1}>
                    {lang === "ar" ? cat.nameAr : cat.nameEn}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}

        {featured.length > 0 && (
          <View style={styles.section}>
            <View style={[styles.sectionHeader, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>{t("featured_products")}</Text>
              <Pressable onPress={() => router.push("/search")}>
                <Text style={[styles.seeAll, { color: colors.primary }]}>{t("see_all")}</Text>
              </Pressable>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.productsRow}
              style={isRTL ? { transform: [{ scaleX: -1 }] } : undefined}
            >
              {featured.map((product: any) => (
                <Pressable
                  key={product.id}
                  style={[
                    styles.productCard,
                    { backgroundColor: colors.card },
                    isRTL ? { transform: [{ scaleX: -1 }] } : undefined,
                  ]}
                  onPress={() => router.push(`/product/${product.id}`)}
                >
                  <Image
                    source={{ uri: product.images?.[0] }}
                    style={styles.productImage}
                    contentFit="cover"
                  />
                  {product.originalPrice && (
                    <View style={[styles.saleBadge, { backgroundColor: colors.error }]}>
                      <Text style={styles.saleBadgeText}>
                        {Math.round((1 - parseFloat(product.price) / parseFloat(product.originalPrice)) * 100)}%
                      </Text>
                    </View>
                  )}
                  <View style={styles.productInfo}>
                    <Text style={[styles.productName, { color: colors.text, textAlign: isRTL ? "right" : "left" }]} numberOfLines={2}>
                      {lang === "ar" ? product.nameAr : product.nameEn}
                    </Text>
                    <View style={[styles.priceRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
                      <Text style={[styles.price, { color: colors.primary }]}>
                        {t("shekel")}{product.price}
                      </Text>
                      {product.originalPrice && (
                        <Text style={[styles.originalPrice, { color: colors.textSecondary }]}>
                          {t("shekel")}{product.originalPrice}
                        </Text>
                      )}
                    </View>
                  </View>
                  <Pressable
                    style={[styles.addBtn, { backgroundColor: colors.primary }]}
                    onPress={(e) => {
                      e.stopPropagation();
                      addItem({
                        productId: product.id,
                        nameAr: product.nameAr,
                        nameEn: product.nameEn,
                        price: product.price,
                        image: product.images?.[0] || "",
                        storeId: product.storeId,
                        storeNameAr: "",
                        storeNameEn: "",
                      });
                    }}
                  >
                    <Ionicons name="add" size={18} color="#FFF" />
                  </Pressable>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function MarqueeAnnouncement({ text, color, isRTL }: { text: string; color: string; isRTL: boolean }) {
  const translateX = useRef(new RNAnimated.Value(SCREEN_WIDTH)).current;

  useEffect(() => {
    const animate = () => {
      translateX.setValue(isRTL ? -SCREEN_WIDTH : SCREEN_WIDTH);
      RNAnimated.timing(translateX, {
        toValue: isRTL ? SCREEN_WIDTH : -SCREEN_WIDTH,
        duration: 12000,
        useNativeDriver: true,
      }).start(() => animate());
    };
    animate();
  }, [isRTL]);

  return (
    <View style={[styles.marqueeContainer, { backgroundColor: color + "10" }]}>
      <Ionicons name="megaphone-outline" size={14} color={color} style={{ marginHorizontal: 8 }} />
      <View style={styles.marqueeOverflow}>
        <RNAnimated.Text
          style={[styles.marqueeText, { color, transform: [{ translateX }] }]}
          numberOfLines={1}
        >
          {text}
        </RNAnimated.Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  header: { paddingHorizontal: 20, paddingBottom: 12 },
  headerRow: { alignItems: "center", gap: 12 },
  greeting: { fontFamily: "Cairo_400Regular", fontSize: 13, marginBottom: 2 },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 22 },
  searchIconBtn: {
    width: 42,
    height: 42,
    borderRadius: 21,
    justifyContent: "center",
    alignItems: "center",
  },
  marqueeContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    marginHorizontal: 16,
    borderRadius: 10,
    marginBottom: 12,
    overflow: "hidden",
  },
  marqueeOverflow: { flex: 1, overflow: "hidden" },
  marqueeText: { fontFamily: "Cairo_600SemiBold", fontSize: 12, width: SCREEN_WIDTH * 2 },
  bannerSection: { marginBottom: 16 },
  bannerItem: {
    width: SCREEN_WIDTH - 32,
    height: 160,
    marginHorizontal: 16,
    borderRadius: 16,
    overflow: "hidden",
  },
  bannerImage: { width: "100%", height: "100%", borderRadius: 16 },
  bannerOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: "rgba(0,0,0,0.3)",
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
  bannerTitle: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "#FFF" },
  dotsContainer: { flexDirection: "row", justifyContent: "center", marginTop: 10, gap: 6 },
  dot: { width: 7, height: 7, borderRadius: 4 },
  section: { marginBottom: 20 },
  sectionHeader: {
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  sectionTitle: { fontFamily: "Cairo_700Bold", fontSize: 18 },
  seeAll: { fontFamily: "Cairo_600SemiBold", fontSize: 13 },
  categoriesRow: { paddingHorizontal: 16, gap: 12 },
  categoryCard: {
    alignItems: "center",
    width: 72,
    gap: 6,
  },
  categoryIconContainer: {
    width: 56,
    height: 56,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
  },
  categoryName: { fontFamily: "Cairo_600SemiBold", fontSize: 11, textAlign: "center" },
  productsRow: { paddingHorizontal: 16, gap: 12 },
  productCard: {
    width: 160,
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  productImage: { width: "100%", height: 160, borderTopLeftRadius: 16, borderTopRightRadius: 16 },
  saleBadge: {
    position: "absolute",
    top: 8,
    left: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  saleBadgeText: { fontFamily: "Cairo_700Bold", fontSize: 11, color: "#FFF" },
  productInfo: { padding: 10, gap: 4 },
  productName: { fontFamily: "Cairo_600SemiBold", fontSize: 13, lineHeight: 18 },
  priceRow: { alignItems: "center", gap: 6 },
  price: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  originalPrice: { fontFamily: "Cairo_400Regular", fontSize: 12, textDecorationLine: "line-through" as const },
  addBtn: {
    position: "absolute",
    bottom: 8,
    right: 8,
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
  },
});
