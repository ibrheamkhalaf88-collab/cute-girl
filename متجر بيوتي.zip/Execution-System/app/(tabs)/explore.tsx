import { StyleSheet, Text, View, ScrollView, Pressable, FlatList, ActivityIndicator, Platform } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language-context";
import Colors from "@/constants/colors";

export default function ExploreScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: cats, isLoading: catsLoading } = useQuery({ queryKey: ["/api/categories"] });
  const { data: storesData, isLoading: storesLoading } = useQuery({ queryKey: ["/api/stores"] });

  const isLoading = catsLoading || storesLoading;

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        contentInsetAdjustmentBehavior="automatic"
      >
        <View style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}>
          <Text style={[styles.headerTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("explore")}
          </Text>
        </View>

        <Pressable
          style={[styles.searchBar, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}
          onPress={() => router.push("/search")}
        >
          <Ionicons name="search" size={18} color={colors.textSecondary} />
          <Text style={[styles.searchPlaceholder, { color: colors.textSecondary }]}>{t("search_products")}</Text>
        </Pressable>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("categories")}
          </Text>
          <View style={styles.categoriesGrid}>
            {(cats || []).map((cat: any) => (
              <Pressable
                key={cat.id}
                style={[styles.categoryGridItem, { backgroundColor: colors.card, borderColor: colors.border }]}
                onPress={() => router.push(`/category/${cat.id}`)}
              >
                <View style={[styles.catIconBg, { backgroundColor: colors.primaryLight }]}>
                  <Ionicons name="sparkles" size={24} color={colors.primary} />
                </View>
                <Text style={[styles.catGridName, { color: colors.text }]} numberOfLines={1}>
                  {lang === "ar" ? cat.nameAr : cat.nameEn}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("stores")}
          </Text>
          {(storesData || []).map((store: any) => (
            <Pressable
              key={store.id}
              style={[styles.storeCard, { backgroundColor: colors.card, flexDirection: isRTL ? "row-reverse" : "row" }]}
              onPress={() => router.push(`/store/${store.id}`)}
            >
              <Image
                source={{ uri: store.logoUrl || "https://images.unsplash.com/photo-1629198688000-71f23e745a41?w=100&h=100&fit=crop" }}
                style={styles.storeLogo}
                contentFit="cover"
              />
              <View style={[styles.storeInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
                <Text style={[styles.storeName, { color: colors.text }]}>
                  {lang === "ar" ? store.nameAr : store.nameEn}
                </Text>
                <Text style={[styles.storeDesc, { color: colors.textSecondary }]} numberOfLines={2}>
                  {lang === "ar" ? store.descriptionAr : store.descriptionEn}
                </Text>
              </View>
              <Ionicons
                name={isRTL ? "chevron-back" : "chevron-forward"}
                size={20}
                color={colors.textSecondary}
              />
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  header: { paddingHorizontal: 20, paddingBottom: 8 },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 26 },
  searchBar: {
    marginHorizontal: 20,
    marginBottom: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 14,
    alignItems: "center",
    gap: 10,
  },
  searchPlaceholder: { fontFamily: "Cairo_400Regular", fontSize: 14 },
  section: { marginBottom: 24, paddingHorizontal: 20 },
  sectionTitle: { fontFamily: "Cairo_700Bold", fontSize: 18, marginBottom: 12 },
  categoriesGrid: { flexDirection: "row", flexWrap: "wrap", gap: 12 },
  categoryGridItem: {
    width: "47%",
    paddingVertical: 16,
    borderRadius: 16,
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
  },
  catIconBg: {
    width: 48,
    height: 48,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  catGridName: { fontFamily: "Cairo_600SemiBold", fontSize: 13 },
  storeCard: {
    alignItems: "center",
    padding: 14,
    borderRadius: 16,
    marginBottom: 10,
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  storeLogo: { width: 50, height: 50, borderRadius: 14 },
  storeInfo: { flex: 1, gap: 2 },
  storeName: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  storeDesc: { fontFamily: "Cairo_400Regular", fontSize: 12, lineHeight: 18 },
});
