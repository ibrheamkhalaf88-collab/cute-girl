import { useState } from "react";
import { StyleSheet, Text, View, TextInput, Pressable, ActivityIndicator, Alert, Platform, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { useCart } from "@/lib/cart-context";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

type PaymentMethod = "BANK_TRANSFER" | "CASH_ON_DELIVERY" | "DEPOSIT_PLUS_DELIVERY";

export default function CheckoutScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { token } = useAuth();
  const { items, subtotal, clearCart } = useCart();
  const colors = Colors.light;
  const queryClient = useQueryClient();
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("CASH_ON_DELIVERY");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);

  const { data: pubSettings } = useQuery({ queryKey: ["/api/settings/public"] });

  const deliveryFee = subtotal >= (pubSettings?.deliveryFreeAbove || 200) ? 0 : (pubSettings?.deliveryFixedFee || 15);
  const total = subtotal + deliveryFee;

  const handlePlaceOrder = async () => {
    if (!address.trim()) {
      Alert.alert("", lang === "ar" ? "يرجى إدخال عنوان التوصيل" : "Please enter delivery address");
      return;
    }
    setLoading(true);
    try {
      const baseUrl = getApiUrl();
      const url = new URL("/api/orders", baseUrl);
      const res = await fetch(url.toString(), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
          paymentMethod,
          deliveryAddress: address.trim(),
          notes: notes.trim(),
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message);
      }
      clearCart();
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert(
        "",
        t("order_placed"),
        [{ text: "OK", onPress: () => router.replace("/(tabs)/orders") }]
      );
    } catch (err: any) {
      Alert.alert("", err.message || "Error");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  const PaymentOption = ({ method, label, icon }: { method: PaymentMethod; label: string; icon: string }) => (
    <Pressable
      style={[
        styles.paymentOption,
        {
          backgroundColor: paymentMethod === method ? colors.primaryLight : colors.inputBg,
          borderColor: paymentMethod === method ? colors.primary : "transparent",
          flexDirection: isRTL ? "row-reverse" : "row",
        },
      ]}
      onPress={() => setPaymentMethod(method)}
    >
      <Ionicons name={icon as any} size={20} color={paymentMethod === method ? colors.primary : colors.textSecondary} />
      <Text style={[styles.paymentLabel, { color: paymentMethod === method ? colors.primary : colors.text }]}>
        {label}
      </Text>
      {paymentMethod === method && (
        <Ionicons name="checkmark-circle" size={20} color={colors.primary} style={{ marginLeft: "auto" }} />
      )}
    </Pressable>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 8, flexDirection: isRTL ? "row-reverse" : "row" }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={24} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{t("checkout")}</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 200 }}
      >
        <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
          {t("delivery_address")}
        </Text>
        <TextInput
          style={[styles.textArea, { backgroundColor: colors.inputBg, color: colors.text, textAlign: isRTL ? "right" : "left" }]}
          placeholder={lang === "ar" ? "أدخل عنوان التوصيل..." : "Enter delivery address..."}
          placeholderTextColor={colors.textSecondary}
          value={address}
          onChangeText={setAddress}
          multiline
        />

        <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
          {t("payment_method")}
        </Text>
        <View style={styles.paymentOptions}>
          <PaymentOption method="CASH_ON_DELIVERY" label={t("cash_on_delivery")} icon="cash-outline" />
          <PaymentOption method="BANK_TRANSFER" label={t("bank_transfer")} icon="card-outline" />
          <PaymentOption method="DEPOSIT_PLUS_DELIVERY" label={t("deposit_delivery")} icon="wallet-outline" />
        </View>

        <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
          {t("notes")}
        </Text>
        <TextInput
          style={[styles.textArea, { backgroundColor: colors.inputBg, color: colors.text, textAlign: isRTL ? "right" : "left" }]}
          placeholder={lang === "ar" ? "ملاحظات إضافية..." : "Additional notes..."}
          placeholderTextColor={colors.textSecondary}
          value={notes}
          onChangeText={setNotes}
          multiline
        />

        <View style={[styles.summaryCard, { backgroundColor: colors.card }]}>
          <SummaryRow label={t("subtotal")} value={`${t("shekel")}${subtotal.toFixed(2)}`} colors={colors} isRTL={isRTL} />
          <SummaryRow
            label={t("delivery_fee")}
            value={deliveryFee === 0 ? t("free") : `${t("shekel")}${deliveryFee.toFixed(2)}`}
            colors={colors}
            isRTL={isRTL}
            valueColor={deliveryFee === 0 ? colors.success : undefined}
          />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <SummaryRow label={t("total")} value={`${t("shekel")}${total.toFixed(2)}`} colors={colors} isRTL={isRTL} bold />
        </View>
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: colors.card, paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 0) + 12 }]}>
        <Pressable
          style={[styles.placeOrderBtn, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]}
          onPress={handlePlaceOrder}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#FFF" />
          ) : (
            <>
              <Text style={styles.placeOrderText}>{t("place_order")}</Text>
              <Text style={styles.placeOrderPrice}>{t("shekel")}{total.toFixed(2)}</Text>
            </>
          )}
        </Pressable>
      </View>
    </View>
  );
}

function SummaryRow({ label, value, colors, isRTL, bold, valueColor }: any) {
  return (
    <View style={[styles.summaryRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
      <Text style={[styles.summaryLabel, bold && styles.summaryBold, { color: colors.text }]}>{label}</Text>
      <Text style={[styles.summaryValue, bold && styles.summaryBold, { color: valueColor || colors.text }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 18 },
  sectionTitle: { fontFamily: "Cairo_700Bold", fontSize: 16, marginBottom: 8, marginTop: 16 },
  textArea: {
    borderRadius: 14,
    padding: 14,
    fontFamily: "Cairo_400Regular",
    fontSize: 14,
    minHeight: 60,
    textAlignVertical: "top",
  },
  paymentOptions: { gap: 8 },
  paymentOption: {
    padding: 14,
    borderRadius: 14,
    alignItems: "center",
    gap: 12,
    borderWidth: 1.5,
  },
  paymentLabel: { fontFamily: "Cairo_600SemiBold", fontSize: 14, flex: 1 },
  summaryCard: {
    marginTop: 20,
    padding: 16,
    borderRadius: 16,
    gap: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  summaryRow: { justifyContent: "space-between", alignItems: "center" },
  summaryLabel: { fontFamily: "Cairo_400Regular", fontSize: 14 },
  summaryValue: { fontFamily: "Cairo_600SemiBold", fontSize: 14 },
  summaryBold: { fontFamily: "Cairo_700Bold", fontSize: 17 },
  divider: { height: 1, marginVertical: 4 },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingTop: 14,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 4,
  },
  placeOrderBtn: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 15,
    borderRadius: 14,
    gap: 12,
  },
  placeOrderText: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "#FFF" },
  placeOrderPrice: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "rgba(255,255,255,0.8)" },
});
