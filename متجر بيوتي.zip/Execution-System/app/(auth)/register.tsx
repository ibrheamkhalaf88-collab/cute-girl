import { useState } from "react";
import { StyleSheet, Text, View, TextInput, Pressable, ActivityIndicator } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function RegisterScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { register } = useAuth();
  const colors = Colors.light;

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleRegister = async () => {
    if (!username.trim() || !password || !confirmPassword) {
      setError(lang === "ar" ? "يرجى ملء جميع الحقول" : "Please fill in all fields");
      return;
    }
    if (password !== confirmPassword) {
      setError(lang === "ar" ? "كلمات المرور غير متطابقة" : "Passwords do not match");
      return;
    }
    if (password.length < 8) {
      setError(lang === "ar" ? "كلمة المرور يجب أن تكون 8 أحرف على الأقل" : "Password must be at least 8 characters");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await register(username.trim(), password);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.dismissAll();
      router.push("/complete-profile");
    } catch (err: any) {
      setError(err.message || (lang === "ar" ? "فشل التسجيل" : "Registration failed"));
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + 60, paddingBottom: insets.bottom + 40 }]}
        bottomOffset={20}
      >
        <Pressable onPress={() => router.back()} style={styles.closeBtn}>
          <Ionicons name="close" size={24} color={colors.text} />
        </Pressable>

        <View style={styles.logoSection}>
          <View style={[styles.logoCircle, { backgroundColor: colors.primaryLight }]}>
            <Ionicons name="sparkles" size={36} color={colors.primary} />
          </View>
          <Text style={[styles.title, { color: colors.text }]}>{t("register")}</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            {lang === "ar" ? "أنشئ حسابك الجديد" : "Create your new account"}
          </Text>
        </View>

        {!!error && (
          <View style={[styles.errorBox, { backgroundColor: colors.error + "15" }]}>
            <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
          </View>
        )}

        <View style={styles.form}>
          <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="person-outline" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("username")}
              placeholderTextColor={colors.textSecondary}
              value={username}
              onChangeText={setUsername}
              autoCapitalize="none"
              autoCorrect={false}
            />
          </View>

          <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="lock-closed-outline" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("password")}
              placeholderTextColor={colors.textSecondary}
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
            />
            <Pressable onPress={() => setShowPassword(!showPassword)}>
              <Ionicons name={showPassword ? "eye-off-outline" : "eye-outline"} size={18} color={colors.textSecondary} />
            </Pressable>
          </View>

          <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="lock-closed-outline" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("confirm_password")}
              placeholderTextColor={colors.textSecondary}
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry={!showPassword}
            />
          </View>

          <Text style={[styles.hint, { color: colors.textSecondary, textAlign: isRTL ? "right" : "left" }]}>
            {lang === "ar"
              ? "كلمة المرور: 8 أحرف، حرف كبير، صغير، رقم، ورمز خاص"
              : "Password: 8+ chars, uppercase, lowercase, number & special char"}
          </Text>

          <Pressable
            style={[styles.submitBtn, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]}
            onPress={handleRegister}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <Text style={styles.submitText}>{t("register")}</Text>
            )}
          </Pressable>
        </View>

        <View style={[styles.footer, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <Text style={[styles.footerText, { color: colors.textSecondary }]}>
            {t("already_have_account")}
          </Text>
          <Pressable onPress={() => router.replace("/(auth)/login")}>
            <Text style={[styles.footerLink, { color: colors.primary }]}>{t("login")}</Text>
          </Pressable>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 24 },
  closeBtn: { alignSelf: "flex-end", padding: 4, marginBottom: 16 },
  logoSection: { alignItems: "center", marginBottom: 32, gap: 8 },
  logoCircle: { width: 72, height: 72, borderRadius: 24, justifyContent: "center", alignItems: "center" },
  title: { fontFamily: "Cairo_700Bold", fontSize: 28 },
  subtitle: { fontFamily: "Cairo_400Regular", fontSize: 15 },
  errorBox: { padding: 12, borderRadius: 12, marginBottom: 16 },
  errorText: { fontFamily: "Cairo_600SemiBold", fontSize: 13, textAlign: "center" },
  form: { gap: 14 },
  inputWrapper: {
    alignItems: "center",
    paddingHorizontal: 16,
    borderRadius: 14,
    gap: 10,
  },
  input: { flex: 1, fontFamily: "Cairo_400Regular", fontSize: 15, paddingVertical: 14 },
  hint: { fontFamily: "Cairo_400Regular", fontSize: 11, lineHeight: 16 },
  submitBtn: { paddingVertical: 15, borderRadius: 14, alignItems: "center", marginTop: 4 },
  submitText: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "#FFF" },
  footer: { justifyContent: "center", gap: 6, marginTop: 24 },
  footerText: { fontFamily: "Cairo_400Regular", fontSize: 14 },
  footerLink: { fontFamily: "Cairo_700Bold", fontSize: 14 },
});
