import { StyleSheet, Text, View, ScrollView, Pressable, ActivityIndicator, Platform } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";
import Colors from "@/constants/colors";

const STATUS_STEPS = [
  "PENDING_PAYMENT",
  "PENDING_RECEIPT",
  "PENDING_ADMIN_REVIEW",
  "PAYMENT_CONFIRMED",
  "PREPARING",
  "READY",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
];

const STATUS_LABELS: Record<string, { ar: string; en: string }> = {
  PENDING_PAYMENT: { ar: "بانتظار الدفع", en: "Pending Payment" },
  PENDING_RECEIPT: { ar: "بانتظار الإيصال", en: "Upload Receipt" },
  PENDING_ADMIN_REVIEW: { ar: "قيد المراجعة", en: "Under Review" },
  PAYMENT_CONFIRMED: { ar: "تم تأكيد الدفع", en: "Confirmed" },
  PREPARING: { ar: "جاري التحضير", en: "Preparing" },
  READY: { ar: "جاهز", en: "Ready" },
  OUT_FOR_DELIVERY: { ar: "في الطريق", en: "On the Way" },
  DELIVERED: { ar: "تم التوصيل", en: "Delivered" },
  CANCELLED: { ar: "ملغي", en: "Cancelled" },
  REJECTED: { ar: "مرفوض", en: "Rejected" },
};

export default function OrderDetailScreen() {
  const { id } = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { token } = useAuth();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: order, isLoading } = useQuery({
    queryKey: ["/api/orders", id],
    queryFn: async () => {
      const baseUrl = getApiUrl();
      const url = new URL(`/api/orders/${id}`, baseUrl);
      const res = await fetch(url.toString(), {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!token,
  });

  if (isLoading) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!order) {
    return (
      <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
        <Text style={{ color: colors.textSecondary }}>Order not found</Text>
      </View>
    );
  }

  const currentStepIndex = STATUS_STEPS.indexOf(order.status);
  const isCancelled = order.status === "CANCELLED" || order.status === "REJECTED";

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 8, flexDirection: isRTL ? "row-reverse" : "row" }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={24} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>{order.orderNumber}</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}>
        <View style={[styles.statusCard, { backgroundColor: colors.card }]}>
          <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
            {t("order_status")}
          </Text>
          {isCancelled ? (
            <View style={[styles.cancelledBadge, { backgroundColor: colors.error + "15" }]}>
              <Ionicons name="close-circle" size={20} color={colors.error} />
              <Text style={[styles.cancelledText, { color: colors.error }]}>
                {STATUS_LABELS[order.status]?.[lang] || order.status}
              </Text>
            </View>
          ) : (
            <View style={styles.timeline}>
              {STATUS_STEPS.slice(0, order.paymentMethod === "CASH_ON_DELIVERY" ? 5 : undefined)
                .filter((s) => order.paymentMethod === "CASH_ON_DELIVERY" ? !["PENDING_RECEIPT", "PENDING_ADMIN_REVIEW"].includes(s) : true)
                .map((step, index, arr) => {
                  const stepIndex = STATUS_STEPS.indexOf(step);
                  const isActive = stepIndex <= currentStepIndex;
                  const isCurrent = step === order.status;
                  return (
                    <View key={step} style={styles.timelineStep}>
                      <View style={styles.timelineLeft}>
                        <View style={[
                          styles.timelineDot,
                          {
                            backgroundColor: isActive ? colors.primary : colors.border,
                            borderColor: isCurrent ? colors.primary : "transparent",
                            borderWidth: isCurrent ? 3 : 0,
                          },
                        ]}>
                          {isActive && <Ionicons name="checkmark" size={10} color="#FFF" />}
                        </View>
                        {index < arr.length - 1 && (
                          <View style={[styles.timelineLine, { backgroundColor: isActive ? colors.primary : colors.border }]} />
                        )}
                      </View>
                      <Text style={[
                        styles.timelineLabel,
                        { color: isActive ? colors.text : colors.textSecondary, textAlign: isRTL ? "right" : "left" },
                        isCurrent && { fontFamily: "Cairo_700Bold" as const },
                      ]}>
                        {STATUS_LABELS[step]?.[lang] || step}
                      </Text>
                    </View>
                  );
                })}
            </View>
          )}
        </View>

        {order.items && order.items.length > 0 && (
          <View style={[styles.itemsCard, { backgroundColor: colors.card }]}>
            <Text style={[styles.sectionTitle, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}>
              {t("items")}
            </Text>
            {order.items.map((item: any) => (
              <View key={item.id} style={[styles.orderItem, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
                <Image
                  source={{ uri: item.product?.images?.[0] }}
                  style={styles.itemImage}
                  contentFit="cover"
                />
                <View style={[styles.itemInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
                  <Text style={[styles.itemName, { color: colors.text }]} numberOfLines={1}>
                    {lang === "ar" ? item.product?.nameAr : item.product?.nameEn}
                  </Text>
                  <Text style={[styles.itemQty, { color: colors.textSecondary }]}>
                    x{item.quantity} · {t("shekel")}{item.price}
                  </Text>
                </View>
                <Text style={[styles.itemTotal, { color: colors.primary }]}>
                  {t("shekel")}{item.total}
                </Text>
              </View>
            ))}
          </View>
        )}

        <View style={[styles.summaryCard, { backgroundColor: colors.card }]}>
          <Row label={t("subtotal")} value={`${t("shekel")}${order.subtotal}`} colors={colors} isRTL={isRTL} />
          <Row label={t("delivery_fee")} value={parseFloat(order.deliveryFee) === 0 ? t("free") : `${t("shekel")}${order.deliveryFee}`} colors={colors} isRTL={isRTL} />
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <Row label={t("total")} value={`${t("shekel")}${order.total}`} colors={colors} isRTL={isRTL} bold />
        </View>
      </ScrollView>
    </View>
  );
}

function Row({ label, value, colors, isRTL, bold }: any) {
  return (
    <View style={[styles.row, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
      <Text style={[styles.rowLabel, bold && styles.boldText, { color: colors.text }]}>{label}</Text>
      <Text style={[styles.rowValue, bold && styles.boldText, { color: colors.text }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  header: { paddingHorizontal: 20, paddingBottom: 12, alignItems: "center", justifyContent: "space-between" },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 18 },
  statusCard: { padding: 16, borderRadius: 16, marginBottom: 12, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 1 },
  sectionTitle: { fontFamily: "Cairo_700Bold", fontSize: 16, marginBottom: 14 },
  cancelledBadge: { flexDirection: "row", alignItems: "center", gap: 8, padding: 12, borderRadius: 12 },
  cancelledText: { fontFamily: "Cairo_700Bold", fontSize: 14 },
  timeline: { gap: 0 },
  timelineStep: { flexDirection: "row", alignItems: "flex-start", gap: 12, minHeight: 40 },
  timelineLeft: { alignItems: "center", width: 22 },
  timelineDot: { width: 22, height: 22, borderRadius: 11, justifyContent: "center", alignItems: "center" },
  timelineLine: { width: 2, flex: 1, minHeight: 18 },
  timelineLabel: { fontFamily: "Cairo_600SemiBold", fontSize: 13, paddingTop: 2 },
  itemsCard: { padding: 16, borderRadius: 16, marginBottom: 12, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 1 },
  orderItem: { alignItems: "center", gap: 12, paddingVertical: 8, borderBottomWidth: 0.5, borderBottomColor: "#F0F0F0" },
  itemImage: { width: 44, height: 44, borderRadius: 10 },
  itemInfo: { flex: 1, gap: 2 },
  itemName: { fontFamily: "Cairo_600SemiBold", fontSize: 13 },
  itemQty: { fontFamily: "Cairo_400Regular", fontSize: 12 },
  itemTotal: { fontFamily: "Cairo_700Bold", fontSize: 14 },
  summaryCard: { padding: 16, borderRadius: 16, gap: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 4, elevation: 1 },
  row: { justifyContent: "space-between", alignItems: "center" },
  rowLabel: { fontFamily: "Cairo_400Regular", fontSize: 14 },
  rowValue: { fontFamily: "Cairo_600SemiBold", fontSize: 14 },
  boldText: { fontFamily: "Cairo_700Bold", fontSize: 17 },
  divider: { height: 1, marginVertical: 4 },
});
