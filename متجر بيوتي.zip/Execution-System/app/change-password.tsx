import { useState } from "react";
import { StyleSheet, Text, View, TextInput, Pressable, ActivityIndicator, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function ChangePasswordScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { changePassword } = useAuth();
  const colors = Colors.light;

  const [currentPwd, setCurrentPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");
  const [confirmPwd, setConfirmPwd] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleChange = async () => {
    if (!currentPwd || !newPwd || !confirmPwd) {
      setError(lang === "ar" ? "يرجى ملء جميع الحقول" : "Please fill all fields");
      return;
    }
    if (newPwd !== confirmPwd) {
      setError(lang === "ar" ? "كلمات المرور غير متطابقة" : "Passwords do not match");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await changePassword({
        currentPassword: currentPwd,
        newPassword: newPwd,
        confirmNewPassword: confirmPwd,
      });
      setSuccess(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(() => router.back(), 1500);
    } catch (err: any) {
      setError(err.message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0) + 20, paddingBottom: insets.bottom + 40 }]}
        bottomOffset={20}
      >
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={24} color={colors.text} />
        </Pressable>

        <Text style={[styles.title, { color: colors.text }]}>{t("change_password")}</Text>

        {!!error && (
          <View style={[styles.errorBox, { backgroundColor: colors.error + "15" }]}>
            <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
          </View>
        )}

        {success && (
          <View style={[styles.errorBox, { backgroundColor: colors.success + "15" }]}>
            <Text style={[styles.errorText, { color: colors.success }]}>
              {lang === "ar" ? "تم تغيير كلمة المرور بنجاح" : "Password changed successfully"}
            </Text>
          </View>
        )}

        <View style={styles.form}>
          <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="lock-closed-outline" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("current_password")}
              placeholderTextColor={colors.textSecondary}
              value={currentPwd}
              onChangeText={setCurrentPwd}
              secureTextEntry
            />
          </View>
          <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="key-outline" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("new_password")}
              placeholderTextColor={colors.textSecondary}
              value={newPwd}
              onChangeText={setNewPwd}
              secureTextEntry
            />
          </View>
          <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="key-outline" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("confirm_password")}
              placeholderTextColor={colors.textSecondary}
              value={confirmPwd}
              onChangeText={setConfirmPwd}
              secureTextEntry
            />
          </View>
          <Pressable
            style={[styles.submitBtn, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]}
            onPress={handleChange}
            disabled={loading}
          >
            {loading ? <ActivityIndicator color="#FFF" /> : <Text style={styles.submitText}>{t("save")}</Text>}
          </Pressable>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 24 },
  backBtn: { padding: 4, alignSelf: "flex-start", marginBottom: 20 },
  title: { fontFamily: "Cairo_700Bold", fontSize: 24, marginBottom: 20 },
  errorBox: { padding: 12, borderRadius: 12, marginBottom: 16 },
  errorText: { fontFamily: "Cairo_600SemiBold", fontSize: 13, textAlign: "center" },
  form: { gap: 14 },
  inputWrapper: { alignItems: "center", paddingHorizontal: 16, borderRadius: 14, gap: 10 },
  input: { flex: 1, fontFamily: "Cairo_400Regular", fontSize: 15, paddingVertical: 14 },
  submitBtn: { paddingVertical: 15, borderRadius: 14, alignItems: "center", marginTop: 8 },
  submitText: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "#FFF" },
});
