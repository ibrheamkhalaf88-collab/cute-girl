import { useState, useCallback } from "react";
import { StyleSheet, Text, View, TextInput, FlatList, Pressable, ActivityIndicator, Platform } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useCart } from "@/lib/cart-context";
import { getApiUrl } from "@/lib/query-client";
import { fetch } from "expo/fetch";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function SearchScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { addItem } = useCart();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const [query, setQuery] = useState("");
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const handleSearch = useCallback(async (text: string) => {
    setQuery(text);
    if (text.length < 2) {
      setResults([]);
      setSearched(false);
      return;
    }
    setLoading(true);
    try {
      const baseUrl = getApiUrl();
      const url = new URL("/api/products", baseUrl);
      url.searchParams.set("search", text);
      const res = await fetch(url.toString());
      if (res.ok) {
        const data = await res.json();
        setResults(data);
      }
    } catch {}
    setSearched(true);
    setLoading(false);
  }, []);

  const renderProduct = ({ item }: any) => (
    <Pressable
      style={[styles.productCard, { backgroundColor: colors.card, flexDirection: isRTL ? "row-reverse" : "row" }]}
      onPress={() => router.push(`/product/${item.id}`)}
    >
      <Image source={{ uri: item.images?.[0] }} style={styles.productImage} contentFit="cover" />
      <View style={[styles.productInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
        <Text style={[styles.productName, { color: colors.text }]} numberOfLines={2}>
          {lang === "ar" ? item.nameAr : item.nameEn}
        </Text>
        <Text style={[styles.price, { color: colors.primary }]}>{t("shekel")}{item.price}</Text>
      </View>
      <Pressable
        style={[styles.addBtn, { backgroundColor: colors.primaryLight }]}
        onPress={() => {
          addItem({
            productId: item.id,
            nameAr: item.nameAr,
            nameEn: item.nameEn,
            price: item.price,
            image: item.images?.[0] || "",
            storeId: item.storeId,
            storeNameAr: "",
            storeNameEn: "",
          });
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }}
      >
        <Ionicons name="add" size={20} color={colors.primary} />
      </Pressable>
    </Pressable>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 8 }]}>
        <View style={[styles.searchRow, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <Pressable onPress={() => router.back()}>
            <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={24} color={colors.text} />
          </Pressable>
          <View style={[styles.searchInput, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Ionicons name="search" size={18} color={colors.textSecondary} />
            <TextInput
              style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
              placeholder={t("search_products")}
              placeholderTextColor={colors.textSecondary}
              value={query}
              onChangeText={handleSearch}
              autoFocus
              autoCorrect={false}
            />
            {query.length > 0 && (
              <Pressable onPress={() => handleSearch("")}>
                <Ionicons name="close-circle" size={18} color={colors.textSecondary} />
              </Pressable>
            )}
          </View>
        </View>
      </View>

      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : searched && results.length === 0 ? (
        <View style={styles.centerContainer}>
          <Ionicons name="search-outline" size={48} color={colors.border} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t("no_products")}</Text>
        </View>
      ) : (
        <FlatList
          data={results}
          renderItem={renderProduct}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 12 },
  searchRow: { alignItems: "center", gap: 10 },
  searchInput: { flex: 1, alignItems: "center", paddingHorizontal: 14, borderRadius: 14, gap: 8 },
  input: { flex: 1, fontFamily: "Cairo_400Regular", fontSize: 15, paddingVertical: 12 },
  centerContainer: { flex: 1, justifyContent: "center", alignItems: "center", gap: 10 },
  emptyText: { fontFamily: "Cairo_600SemiBold", fontSize: 15 },
  listContent: { padding: 16, gap: 8 },
  productCard: {
    padding: 12,
    borderRadius: 16,
    alignItems: "center",
    gap: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  productImage: { width: 64, height: 64, borderRadius: 12 },
  productInfo: { flex: 1, gap: 4 },
  productName: { fontFamily: "Cairo_600SemiBold", fontSize: 14, lineHeight: 20 },
  price: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
});
