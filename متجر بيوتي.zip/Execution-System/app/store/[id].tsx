import { StyleSheet, Text, View, FlatList, Pressable, ActivityIndicator, Platform } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { useLanguage } from "@/lib/language-context";
import { useCart } from "@/lib/cart-context";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function StoreScreen() {
  const { id } = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { addItem } = useCart();
  const colors = Colors.light;
  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const { data: store, isLoading: storeLoading } = useQuery({
    queryKey: ["/api/stores", id],
  });

  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["/api/products"],
    queryFn: async () => {
      const baseUrl = process.env.EXPO_PUBLIC_DOMAIN;
      const res = await fetch(`https://${baseUrl}/api/products?storeId=${id}`);
      return res.json();
    },
  });

  const isLoading = storeLoading || productsLoading;

  const renderProduct = ({ item }: any) => (
    <Pressable
      style={[styles.productCard, { backgroundColor: colors.card }]}
      onPress={() => router.push(`/product/${item.id}`)}
    >
      <Image source={{ uri: item.images?.[0] }} style={styles.productImage} contentFit="cover" />
      <View style={[styles.productInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
        <Text style={[styles.productName, { color: colors.text, textAlign: isRTL ? "right" : "left" }]} numberOfLines={2}>
          {lang === "ar" ? item.nameAr : item.nameEn}
        </Text>
        <Text style={[styles.price, { color: colors.primary }]}>{t("shekel")}{item.price}</Text>
      </View>
      <Pressable
        style={[styles.addBtn, { backgroundColor: colors.primary }]}
        onPress={() => {
          addItem({
            productId: item.id,
            nameAr: item.nameAr,
            nameEn: item.nameEn,
            price: item.price,
            image: item.images?.[0] || "",
            storeId: item.storeId,
            storeNameAr: store?.nameAr || "",
            storeNameEn: store?.nameEn || "",
          });
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        }}
      >
        <Ionicons name="add" size={18} color="#FFF" />
      </Pressable>
    </Pressable>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.header, { paddingTop: insets.top + webTopInset + 8, flexDirection: isRTL ? "row-reverse" : "row" }]}>
        <Pressable onPress={() => router.back()}>
          <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={24} color={colors.text} />
        </Pressable>
        <Text style={[styles.headerTitle, { color: colors.text }]}>
          {store ? (lang === "ar" ? store.nameAr : store.nameEn) : ""}
        </Text>
        <View style={{ width: 24 }} />
      </View>

      {store && (
        <View style={[styles.storeHeader, { flexDirection: isRTL ? "row-reverse" : "row" }]}>
          <Image
            source={{ uri: store.logoUrl }}
            style={styles.storeLogo}
            contentFit="cover"
          />
          <View style={[styles.storeInfo, { alignItems: isRTL ? "flex-end" : "flex-start" }]}>
            <Text style={[styles.storeName, { color: colors.text }]}>
              {lang === "ar" ? store.nameAr : store.nameEn}
            </Text>
            <Text style={[styles.storeDesc, { color: colors.textSecondary }]} numberOfLines={2}>
              {lang === "ar" ? store.descriptionAr : store.descriptionEn}
            </Text>
          </View>
        </View>
      )}

      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : (!products || products.length === 0) ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="cube-outline" size={56} color={colors.border} />
          <Text style={[styles.emptyText, { color: colors.textSecondary }]}>{t("no_products")}</Text>
        </View>
      ) : (
        <FlatList
          data={products}
          renderItem={renderProduct}
          keyExtractor={(item) => String(item.id)}
          numColumns={2}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerTitle: { fontFamily: "Cairo_700Bold", fontSize: 18 },
  storeHeader: {
    marginHorizontal: 20,
    padding: 16,
    borderRadius: 16,
    backgroundColor: "#FFF",
    alignItems: "center",
    gap: 14,
    marginBottom: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  storeLogo: { width: 56, height: 56, borderRadius: 16 },
  storeInfo: { flex: 1, gap: 4 },
  storeName: { fontFamily: "Cairo_700Bold", fontSize: 17 },
  storeDesc: { fontFamily: "Cairo_400Regular", fontSize: 13, lineHeight: 20 },
  loadingContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  emptyContainer: { flex: 1, justifyContent: "center", alignItems: "center", gap: 10 },
  emptyText: { fontFamily: "Cairo_600SemiBold", fontSize: 15 },
  listContent: { padding: 16, paddingBottom: 40 },
  row: { justifyContent: "space-between", marginBottom: 12 },
  productCard: {
    width: "48%",
    borderRadius: 16,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 4,
    elevation: 1,
  },
  productImage: { width: "100%", height: 150 },
  productInfo: { padding: 10, gap: 4 },
  productName: { fontFamily: "Cairo_600SemiBold", fontSize: 13, lineHeight: 18 },
  price: { fontFamily: "Cairo_700Bold", fontSize: 15 },
  addBtn: {
    position: "absolute",
    bottom: 8,
    right: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
  },
});
