import { useState } from "react";
import { StyleSheet, Text, View, TextInput, Pressable, ActivityIndicator, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useLanguage } from "@/lib/language-context";
import { useAuth } from "@/lib/auth-context";
import { KeyboardAwareScrollViewCompat } from "@/components/KeyboardAwareScrollViewCompat";
import * as Haptics from "expo-haptics";
import Colors from "@/constants/colors";

export default function CompleteProfileScreen() {
  const insets = useSafeAreaInsets();
  const { lang, isRTL, t } = useLanguage();
  const { user, completeProfile } = useAuth();
  const colors = Colors.light;

  const [fullName, setFullName] = useState(user?.fullName || "");
  const [email, setEmail] = useState(user?.email || "");
  const [phone, setPhone] = useState(user?.phoneNumber || "");
  const [address, setAddress] = useState(user?.addressArea || "");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSave = async () => {
    if (!fullName.trim() || !email.trim() || !phone.trim()) {
      setError(lang === "ar" ? "يرجى ملء الحقول المطلوبة" : "Please fill required fields");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await completeProfile({
        fullName: fullName.trim(),
        email: email.trim(),
        phoneNumber: phone.trim(),
        addressArea: address.trim() || undefined,
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (err: any) {
      setError(err.message);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAwareScrollViewCompat
        style={styles.scroll}
        contentContainerStyle={[styles.content, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0) + 20, paddingBottom: insets.bottom + 40 }]}
        bottomOffset={20}
      >
        <View style={styles.headerRow}>
          <Pressable onPress={() => router.back()} style={styles.backBtn}>
            <Ionicons name={isRTL ? "arrow-forward" : "arrow-back"} size={24} color={colors.text} />
          </Pressable>
        </View>

        <View style={styles.titleSection}>
          <View style={[styles.iconBg, { backgroundColor: colors.primaryLight }]}>
            <Ionicons name="person-circle" size={40} color={colors.primary} />
          </View>
          <Text style={[styles.title, { color: colors.text }]}>{t("complete_profile")}</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>{t("complete_profile_desc")}</Text>
        </View>

        {!!error && (
          <View style={[styles.errorBox, { backgroundColor: colors.error + "15" }]}>
            <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
          </View>
        )}

        <View style={styles.form}>
          <InputField
            icon="person-outline"
            placeholder={t("full_name") + " *"}
            value={fullName}
            onChangeText={setFullName}
            colors={colors}
            isRTL={isRTL}
          />
          <InputField
            icon="mail-outline"
            placeholder={t("email") + " *"}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            colors={colors}
            isRTL={isRTL}
          />
          <InputField
            icon="call-outline"
            placeholder={t("phone") + " *"}
            value={phone}
            onChangeText={setPhone}
            keyboardType="phone-pad"
            colors={colors}
            isRTL={isRTL}
          />
          <InputField
            icon="location-outline"
            placeholder={t("address")}
            value={address}
            onChangeText={setAddress}
            colors={colors}
            isRTL={isRTL}
          />

          <Pressable
            style={[styles.submitBtn, { backgroundColor: colors.primary, opacity: loading ? 0.7 : 1 }]}
            onPress={handleSave}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFF" />
            ) : (
              <Text style={styles.submitText}>{t("save")}</Text>
            )}
          </Pressable>
        </View>
      </KeyboardAwareScrollViewCompat>
    </View>
  );
}

function InputField({ icon, placeholder, value, onChangeText, keyboardType, colors, isRTL }: any) {
  return (
    <View style={[styles.inputWrapper, { backgroundColor: colors.inputBg, flexDirection: isRTL ? "row-reverse" : "row" }]}>
      <Ionicons name={icon} size={18} color={colors.textSecondary} />
      <TextInput
        style={[styles.input, { color: colors.text, textAlign: isRTL ? "right" : "left" }]}
        placeholder={placeholder}
        placeholderTextColor={colors.textSecondary}
        value={value}
        onChangeText={onChangeText}
        keyboardType={keyboardType}
        autoCapitalize="none"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { flex: 1 },
  content: { paddingHorizontal: 24 },
  headerRow: { marginBottom: 16 },
  backBtn: { padding: 4, alignSelf: "flex-start" },
  titleSection: { alignItems: "center", marginBottom: 28, gap: 8 },
  iconBg: { width: 72, height: 72, borderRadius: 24, justifyContent: "center", alignItems: "center" },
  title: { fontFamily: "Cairo_700Bold", fontSize: 24 },
  subtitle: { fontFamily: "Cairo_400Regular", fontSize: 14, textAlign: "center" },
  errorBox: { padding: 12, borderRadius: 12, marginBottom: 16 },
  errorText: { fontFamily: "Cairo_600SemiBold", fontSize: 13, textAlign: "center" },
  form: { gap: 14 },
  inputWrapper: { alignItems: "center", paddingHorizontal: 16, borderRadius: 14, gap: 10 },
  input: { flex: 1, fontFamily: "Cairo_400Regular", fontSize: 15, paddingVertical: 14 },
  submitBtn: { paddingVertical: 15, borderRadius: 14, alignItems: "center", marginTop: 8 },
  submitText: { fontFamily: "Cairo_700Bold", fontSize: 16, color: "#FFF" },
});
