# Beauty Zone - Bilingual Cosmetics Marketplace

## Overview
Beauty Zone is a bilingual (Arabic/English) mobile marketplace for cosmetics stores in Gaza. Built with Expo React Native for the mobile app and Express + PostgreSQL for the backend.

## Architecture
- **Mobile App**: Expo React Native with file-based routing (Expo Router)
- **Backend**: Express.js + TypeScript on port 5000
- **Database**: PostgreSQL with Drizzle ORM
- **Auth**: JWT-based with bcrypt password hashing

## Key Features
- Bilingual Arabic (RTL) / English (LTR) with runtime language switching
- JWT authentication with registration, login, profile completion
- Master Admin with RBAC permission system
- Dynamic categories, products, stores
- Shopping cart and checkout with multiple payment methods
- Order tracking with status timeline
- Dynamic home page with banners, announcements, categories, featured products

## Project Structure
```
app/                    # Expo Router pages
  (tabs)/               # Tab-based navigation (Home, Explore, Cart, Orders, Account)
  (auth)/               # Auth modal (Login, Register)
  product/[id].tsx      # Product details
  store/[id].tsx        # Store page
  category/[id].tsx     # Category listing
  checkout.tsx          # Checkout flow
  order/[id].tsx        # Order details
  search.tsx            # Search
  complete-profile.tsx  # Profile completion
  change-password.tsx   # Password change
lib/                    # Contexts and utilities
  auth-context.tsx      # Auth state management
  language-context.tsx  # i18n with AR/EN translations
  cart-context.tsx      # Shopping cart state
  query-client.ts       # React Query + API client
server/                 # Express backend
  index.ts              # Server entry
  routes.ts             # API routes
  storage.ts            # Database operations
  seed.ts               # Initial data seeding
  db.ts                 # Database connection
shared/schema.ts        # Drizzle schema (all tables)
constants/colors.ts     # Theme colors
```

## Theme
- Soft pink/coral (#E8657A) primary color
- Cream beige backgrounds
- Cairo font family (Arabic + English support)
- Feminine, clean, modern aesthetic

## Master Admin
- Username: 424230795
- Force password change on first login
- Full RBAC permission system

## Recent Changes
- Initial MVP build with full marketplace functionality
