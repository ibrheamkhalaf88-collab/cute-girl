import { sql } from "drizzle-orm";
import {
  pgTable,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  jsonb,
  decimal,
  serial,
  pgEnum,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoleEnum = pgEnum("user_role", [
  "USER",
  "STORE_OWNER",
  "ADMIN",
  "MASTER_ADMIN",
]);

export const orderStatusEnum = pgEnum("order_status", [
  "PENDING_PAYMENT",
  "PENDING_RECEIPT",
  "PENDING_ADMIN_REVIEW",
  "PAYMENT_CONFIRMED",
  "PREPARING",
  "READY",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
  "CANCELLED",
  "REJECTED",
]);

export const paymentMethodEnum = pgEnum("payment_method", [
  "BANK_TRANSFER",
  "DEPOSIT_PLUS_DELIVERY",
  "CASH_ON_DELIVERY",
]);

export const ticketStatusEnum = pgEnum("ticket_status", [
  "OPEN",
  "IN_PROGRESS",
  "RESOLVED",
  "CLOSED",
]);

export const users = pgTable("users", {
  id: varchar("id")
    .primaryKey()
    .default(sql`gen_random_uuid()`),
  userIdPublic: varchar("user_id_public")
    .notNull()
    .unique()
    .default(sql`'BZ-' || substr(gen_random_uuid()::text, 1, 8)`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: userRoleEnum("role").notNull().default("USER"),
  fullName: text("full_name"),
  email: text("email"),
  phoneNumber: text("phone_number"),
  addressArea: text("address_area"),
  phoneVerified: boolean("phone_verified").default(false),
  profileCompleted: boolean("profile_completed").default(false),
  forcePasswordChange: boolean("force_password_change").default(false),
  isActive: boolean("is_active").default(true),
  preferredLanguage: varchar("preferred_language", { length: 2 }).default("ar"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const permissions = pgTable("permissions", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  description: text("description"),
});

export const adminUserPermissions = pgTable("admin_user_permissions", {
  id: serial("id").primaryKey(),
  adminUserId: varchar("admin_user_id")
    .notNull()
    .references(() => users.id),
  permissionId: integer("permission_id")
    .notNull()
    .references(() => permissions.id),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  iconUrl: text("icon_url"),
  orderIndex: integer("order_index").default(0),
  isActive: boolean("is_active").default(true),
  showOnHome: boolean("show_on_home").default(true),
  visibilityMode: varchar("visibility_mode", { length: 50 }).default(
    "HIDE_CATEGORY_ONLY"
  ),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  ownerId: varchar("owner_id")
    .notNull()
    .references(() => users.id),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  logoUrl: text("logo_url"),
  coverUrl: text("cover_url"),
  whatsappNumber: text("whatsapp_number"),
  bankName: text("bank_name"),
  bankAccountNumber: text("bank_account_number"),
  bankAccountHolder: text("bank_account_holder"),
  commissionOverride: decimal("commission_override"),
  isApproved: boolean("is_approved").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const storeApplications = pgTable("store_applications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id),
  storeNameAr: text("store_name_ar").notNull(),
  storeNameEn: text("store_name_en").notNull(),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  status: varchar("status", { length: 20 }).default("PENDING"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  storeId: integer("store_id")
    .notNull()
    .references(() => stores.id),
  categoryId: integer("category_id")
    .notNull()
    .references(() => categories.id),
  nameAr: text("name_ar").notNull(),
  nameEn: text("name_en").notNull(),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  originalPrice: decimal("original_price", { precision: 10, scale: 2 }),
  images: jsonb("images").$type<string[]>().default([]),
  suitableFor: text("suitable_for"),
  usagePurpose: text("usage_purpose"),
  howToUse: text("how_to_use"),
  warnings: text("warnings"),
  ingredients: text("ingredients"),
  stock: integer("stock").default(0),
  isActive: boolean("is_active").default(true),
  isFeatured: boolean("is_featured").default(false),
  orderIndex: integer("order_index").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const productCustomFields = pgTable("product_custom_fields", {
  id: serial("id").primaryKey(),
  labelAr: text("label_ar").notNull(),
  labelEn: text("label_en").notNull(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  fieldType: varchar("field_type", { length: 20 }).notNull(),
  required: boolean("required").default(false),
  options: jsonb("options"),
  orderIndex: integer("order_index").default(0),
  isActive: boolean("is_active").default(true),
});

export const productCustomValues = pgTable("product_custom_values", {
  id: serial("id").primaryKey(),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  fieldId: integer("field_id")
    .notNull()
    .references(() => productCustomFields.id),
  value: text("value"),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: varchar("order_number", { length: 20 })
    .notNull()
    .unique()
    .default(sql`'ORD-' || substr(gen_random_uuid()::text, 1, 8)`),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id),
  storeId: integer("store_id")
    .notNull()
    .references(() => stores.id),
  status: orderStatusEnum("status").default("PENDING_PAYMENT"),
  paymentMethod: paymentMethodEnum("payment_method"),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
  deliveryFee: decimal("delivery_fee", { precision: 10, scale: 2 }).default("0"),
  discount: decimal("discount", { precision: 10, scale: 2 }).default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  commissionAmount: decimal("commission_amount", { precision: 10, scale: 2 }),
  depositAmount: decimal("deposit_amount", { precision: 10, scale: 2 }),
  senderAccountNumber: text("sender_account_number"),
  receiptImageUrl: text("receipt_image_url"),
  receiptUploadedAt: timestamp("receipt_uploaded_at"),
  deliveryAddress: text("delivery_address"),
  notes: text("notes"),
  adminReviewNotes: text("admin_review_notes"),
  cancelledAt: timestamp("cancelled_at"),
  cancelReason: text("cancel_reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => orders.id),
  productId: integer("product_id")
    .notNull()
    .references(() => products.id),
  quantity: integer("quantity").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
});

export const homeSections = pgTable("home_sections", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  type: varchar("type", { length: 50 }).notNull(),
  configJSON: jsonb("config_json"),
  orderIndex: integer("order_index").default(0),
  isActive: boolean("is_active").default(true),
});

export const adsBanners = pgTable("ads_banners", {
  id: serial("id").primaryKey(),
  titleAr: text("title_ar"),
  titleEn: text("title_en"),
  imageUrlAr: text("image_url_ar"),
  imageUrlEn: text("image_url_en"),
  linkType: varchar("link_type", { length: 20 }),
  linkTarget: text("link_target"),
  orderIndex: integer("order_index").default(0),
  isActive: boolean("is_active").default(true),
  startAt: timestamp("start_at"),
  endAt: timestamp("end_at"),
});

export const movingAnnouncements = pgTable("moving_announcements", {
  id: serial("id").primaryKey(),
  textAr: text("text_ar").notNull(),
  textEn: text("text_en").notNull(),
  isActive: boolean("is_active").default(true),
  startAt: timestamp("start_at"),
  endAt: timestamp("end_at"),
  speed: integer("speed").default(50),
});

export const uiTexts = pgTable("ui_texts", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 200 }).notNull().unique(),
  ar: text("ar").notNull(),
  en: text("en").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 200 }).notNull().unique(),
  valueJSON: jsonb("value_json"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const contentBlocks = pgTable("content_blocks", {
  id: serial("id").primaryKey(),
  type: varchar("type", { length: 50 }).notNull(),
  payloadJSON: jsonb("payload_json"),
  orderIndex: integer("order_index").default(0),
  isActive: boolean("is_active").default(true),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id),
  category: varchar("category", { length: 50 }).notNull(),
  subject: text("subject").notNull(),
  status: ticketStatusEnum("status").default("OPEN"),
  orderId: integer("order_id").references(() => orders.id),
  assignedAdminId: varchar("assigned_admin_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const ticketMessages = pgTable("ticket_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id")
    .notNull()
    .references(() => tickets.id),
  senderId: varchar("sender_id")
    .notNull()
    .references(() => users.id),
  message: text("message").notNull(),
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id")
    .notNull()
    .references(() => users.id),
  titleAr: text("title_ar").notNull(),
  titleEn: text("title_en").notNull(),
  bodyAr: text("body_ar").notNull(),
  bodyEn: text("body_en").notNull(),
  type: varchar("type", { length: 50 }),
  entityId: text("entity_id"),
  isRead: boolean("is_read").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  actorUserId: varchar("actor_user_id").references(() => users.id),
  action: text("action").notNull(),
  entityType: varchar("entity_type", { length: 50 }),
  entityId: text("entity_id"),
  beforeJSON: jsonb("before_json"),
  afterJSON: jsonb("after_json"),
  ip: text("ip"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

export const registerSchema = z.object({
  username: z.string().min(3).max(50),
  password: z
    .string()
    .min(8)
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
      "Password must contain uppercase, lowercase, number and special character"
    ),
});

export const profileCompletionSchema = z.object({
  fullName: z.string().min(2),
  email: z.string().email(),
  phoneNumber: z.string().min(8),
  addressArea: z.string().optional(),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z
    .string()
    .min(8)
    .regex(
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/
    ),
  confirmNewPassword: z.string().min(1),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Store = typeof stores.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type OrderItem = typeof orderItems.$inferSelect;
export type HomeSectionType = typeof homeSections.$inferSelect;
export type AdsBanner = typeof adsBanners.$inferSelect;
export type MovingAnnouncement = typeof movingAnnouncements.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketMessage = typeof ticketMessages.$inferSelect;
